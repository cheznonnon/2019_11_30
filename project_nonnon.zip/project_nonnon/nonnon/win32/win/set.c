// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_SET
#define _H_NONNON_WIN32_WIN_SET




#include "./dwm.c"
#include "./rect.c"
#include "./style.c"


#include "../sysinfo/version.c"




#include <shellapi.h>




typedef struct {

	// [ In/Out : Overridable ]


	// Window Position

	s32 posx, posy;


	// Real Client Size : hidden area is included

	s32 rcsx, rcsy;


	// [ Out : Auto-calculated ]


	// Client Size : visible area only

	s32 csx, csy;


	// Window Size : caption and borders are included

	s32 wsx, wsy;


	// Scroll Position

	s32 scrollx, scrolly;


	// Window State
	//
	//	same as wParam of WM_SIZE
	//
	//	0 == SIZE_RESTORED
	//	1 == SIZE_MINIMIZED
	//	2 == SIZE_MAXIMIZED

	int state;

} n_win;




#define n_win_zero(  f    ) n_memory_zero( f,    sizeof( n_win ) )
#define n_win_alias( f, t ) n_memory_copy( f, t, sizeof( n_win ) )

void
n_win_taskbarpos( int *ret_p, RECT *ret_r )
{

	// [x] : don't use SHAppBarMessage() : buggy
	//
	//	WinNT : don't use ABM_QUERYPOS : abd.rc will be zero
	//	Win9x : abd.uEdge will be zero(ABE_LEFT) in some cases

	// [Needed] : handling as range


	int  p = -1;
	RECT r; 


#ifdef _MSC_VER

	APPBARDATA abd; ZeroMemory( &abd, sizeof( APPBARDATA ) );
	abd.cbSize = sizeof( APPBARDATA );
	abd.hWnd   = NULL;
	SHAppBarMessage( ABM_GETTASKBARPOS, &abd );

	p = abd.uEdge;
	r = abd.rc;

#else  // #ifdef _MSC_VER

	s32 fx,fy,fsx,fsy;

	fx = fy = 0;
	n_win_desktop_size( &fsx, &fsy );


	s32 tx,ty,tsx,tsy;

	HWND h = n_win_hwnd_find_literal( NULL, "Shell_TrayWnd" );
	GetWindowRect( h, &r );

	n_win_rect_expand_range( &r, &tx, &ty, &tsx, &tsy );


	if ( ( tx <= fx )&&( ty <= fy ) )
	{

		if ( tsx >= fsx ) { p = ABE_TOP;  }
		if ( tsy >= fsy ) { p = ABE_LEFT; }

	} else

	if ( ( tsx >= fsx )&&( tsy >= fsy ) )
	{

		if ( tx <= fx ) { p = ABE_BOTTOM; }
		if ( ty <= fy ) { p = ABE_RIGHT;  }

	}

#endif // #ifdef _MSC_VER


	if ( ret_p != NULL ) { (*ret_p) = p; }
	if ( ret_r != NULL ) { (*ret_r) = r; }


	return;
}

inline void
n_win_minsize_proc_patch( HWND hwnd, s32 *csx, s32 *csy )
{

	// [Needed] : VC++ 2017

#ifdef _MSC_VER

	// [x] : reason is unknown

	if ( csx != NULL ) { (*csx) -= 5 * ( n_win_dpi( hwnd ) / 96 ); }
	if ( csy != NULL ) { (*csy) -= 5 * ( n_win_dpi( hwnd ) / 96 ); }

#endif // #ifdef _MSC_VER

	return;
}

void
n_win_minsize_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, s32 csx, s32 csy )
{

	// [Mechanism] : for resizable window like WS_OVERLAPPEDWINDOW


	if ( msg != WM_GETMINMAXINFO ) { return; }


	MINMAXINFO *m = (void*) lparam;
	if ( m == NULL ) { return; }


	// [!] : don't use Get*Rect() : buggy

	const s32 barsy = GetSystemMetrics( SM_CYCAPTION );

	const s32 ncsx  = ( GetSystemMetrics( SM_CXSIZEFRAME ) * 2 );
	const s32 ncsy  = ( GetSystemMetrics( SM_CXSIZEFRAME ) * 2 ) + barsy;


	// [x] : buggy : patched

	s32 patch_sx = 0;
	s32 patch_sy = 0;

/*
	// [!] : Win10 build 10130 : not needed

	if ( n_sysinfo_version_10_or_later() )
	{
		patch_sx = GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
		patch_sy = GetSystemMetrics( SM_CYSIZEFRAME ) * 2;
	}
*/

#ifdef _MSC_VER

	// [x] : reason is unknown

	// [x] : buggy : use n_win_minsize_proc_patch()
	//
	//	you need subtract "5px * dpi_scale" from client area size

	patch_sx = GetSystemMetrics( SM_CXSIZEFRAME ) * 2;
	patch_sy = GetSystemMetrics( SM_CYSIZEFRAME ) * 2;

#endif // #ifdef _MSC_VER


	m->ptMinTrackSize.x = ncsx + csx + patch_sx;
	m->ptMinTrackSize.y = ncsy + csy + patch_sy;


	return;
}

bool
n_win_fake_win7_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, LRESULT *ret )
{

	// [Mechanism]
	//
	//	call in a window procedure/WndProc() like this
	//
	//	{
	//		LRESULT ret = 0;
	//		if ( n_win_fake_win7_proc( hwnd, msg, wparam, lparam, &ret ) )
	//		{
	//			return ret;
	//		}
	//	}


	if ( n_sysinfo_realversion_7_or_later() ) { return false; }

	if ( false == ( WS_SIZEBOX & n_win_style_get( hwnd ) ) ) { return false; }


	static RECT rect  = { 0,0,0,0 };
	static bool onoff = false;
	static bool drag  = false;
	static s32  oy    = 0;


	switch( msg ) {


	case WM_NCLBUTTONDBLCLK :

		if (
			( HTTOP    == LOWORD( wparam ) )
			||
			( HTBOTTOM == LOWORD( wparam ) )
		)
		{
//n_win_hwndprintf_literal( hwnd, " HTTOP/HTBOTTOM " );

			if ( onoff )
			{

				onoff = false;

				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				n_win_move_simple( hwnd, x,y,sx,sy, true );

			} else {

				onoff = true;

				GetWindowRect( hwnd, &rect );
				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				s32 borders = GetSystemMetrics( SM_CYSIZEFRAME ) * 2;

				 y = 0;
				sy = GetSystemMetrics( SM_CYMAXIMIZED ) - borders;

				n_win_move_simple( hwnd, x,y,sx,sy, true );

			}

		} else
		if ( HTCAPTION == LOWORD( wparam ) )
		{
//n_win_hwndprintf_literal( hwnd, " HTCAPTION " );

			if ( onoff )
			{

				onoff = false;

				s32 x,y,sx,sy; n_win_rect_expand_size( &rect, &x, &y, &sx, &sy );
				n_win_move_simple( hwnd, x,y,sx,sy, true );

				if ( ret != NULL ) { (*ret) = 0; }
				return true;
			}

		}

	break;

	case WM_NCLBUTTONDOWN :

		if ( HTCAPTION == LOWORD( wparam ) )
		{
			n_win_cursor_position( NULL, &oy );
		}

	break;

	case WM_MOVING :
//n_win_hwndprintf_literal( hwnd, " %08x %08x ", GetKeyState( VK_LBUTTON ), GetAsyncKeyState( VK_LBUTTON ) );
//n_win_hwndprintf_literal( hwnd, " %d ", onoff );

		if ( onoff )
		{

			RECT *r = (RECT*) lparam;
			if ( r == NULL ) { break; }

			bool drag_full_windows = false;
			SystemParametersInfo( SPI_GETDRAGFULLWINDOWS, 0, (void*) &drag_full_windows, 0 );

			s32 caption  = GetSystemMetrics( SM_CYCAPTION );
			s32 limit_sy = caption * 4;
			s32 cursor_x = 0;
			s32 cursor_y = 0; n_win_cursor_position( &cursor_x, &cursor_y );
//n_win_hwndprintf_literal( hwnd, " %d / %d ", cursor_y, limit_sy );

			s32 x,y,sx,sy;

			bool finalize = false;

			if ( cursor_y > limit_sy )
			{
				onoff = false;

				n_win_rect_expand_size(     r,   &x, NULL, NULL, NULL );
				n_win_rect_expand_size( &rect, NULL, NULL,  &sx,  &sy );

				// [Patch] : Win95 : borders will remain sometimes
				if ( drag_full_windows == false )
				{
					x = x + GetSystemMetrics( SM_CXSIZEFRAME );
				}

				y = cursor_y - oy;

				finalize = true;
			} else {
				n_win_rect_expand_size(     r,   &x,   &y,  &sx,  &sy );
				y = 0;
			}

			n_win_rect_set( r, x, y, sx, sy );


			// [Needed] : WinXP or earlier : when drag full window is off

			if ( finalize )
			{
				if ( drag_full_windows == false ) { drag = true; }
			}

		}

	break;

	case WM_MOVE :

		if ( drag )
		{

			drag  = false;
			onoff = false;

			s32 x,y,sx,sy; n_win_rect_expand_size( &rect, NULL, NULL, &sx, &sy );
			s32 cursor_y = 0; n_win_cursor_position( NULL, &cursor_y );
			x = LOWORD( lparam );
			y = cursor_y - oy;
			n_win_move_simple( hwnd, x,y,sx,sy, true );


			// [Needed] : Win9x : when drag full window is off

			//UpdateWindow( hwnd );
			n_win_refresh( hwnd, true );


			if ( ret != NULL ) { (*ret) = 0; }
			return true;
		}

	break;


	} // switch


	return false;
}

void
n_win_set_patch( HWND hwnd, s32 *csx, s32 *csy, s32 patch_sx, s32 patch_sy )
{

#ifdef _MSC_VER

	// [x] : reason is unknown

	s32 dpi   = n_win_dpi( hwnd );
	s32 scale = dpi / 96;

	if ( ( dpi != 96 )&&( scale == 1 ) )
	{
		if ( csx != NULL ) { (*csx) += patch_sx; }
		if ( csy != NULL ) { (*csy) += patch_sy; }
	}

#endif // #ifdef _MSC_VER


	return;
}

#define N_WIN_SET_DEFAULT     ( 0       )
#define N_WIN_SET_CENTERING   ( 1 <<  0 )
#define N_WIN_SET_INNERPOS    ( 1 <<  1 )
#define N_WIN_SET_CLIPPING    ( 1 <<  2 )
#define N_WIN_SET_SCROLLBAR   ( 1 <<  3 )
#define N_WIN_SET_NEEDPOS     ( 1 <<  4 )
#define N_WIN_SET_FORCEPOS    ( 1 <<  5 )
#define N_WIN_SET_CALCONLY    ( 1 <<  6 )
#define N_WIN_SET_RESTORE     ( 1 <<  7 )

void
n_win_set( HWND hwnd, n_win *w_ret, s32 rcsx, s32 rcsy, int mode )
{

	// [Mechanism]
	//
	//	"rcsx" "rcsy"
	//		-1 : auto-calculation
	//
	//	"mode" : N_WIN_SET_*
	//
	//		CENTERING  : centering
	//		INNERPOS   : clamp when out of screen
	//		CLIPPING   : clipping by desktop size
	//		SCROLLBAR  : calculate for scrollbars
	//		NEEDPOS    : override : posx, posy : before other options
	//		FORCEPOS   : override : posx, posy :  after other options
	//		CALCONLY   : calculation only
	//		RESTORE    : for resotre position, size and state, using n_win.state


	// [x] : Troubleshooter : ShowWindow() misbehaves at WM_CREATE
	//
	//	1 : SetWindowPos() always uses ShowWindow() internally
	//	2 : ShowWindow() will be suppressed until the first DefWindowProc() call
	//	3 : a first set SW_* will be used


	// [!] : How to Restore Window position
	//
	//	use N_WIN_SET_RESTORE
	//
	//	[Normal Window]
	//	1 : call n_win_set()
	//	2 : call ShwoWindow( hwnd, SW_SHOWNORMAL );
	//
	//	[Maximized Window]
	//	1 : call n_win_set() with N_WIN_SET_CALCONLY
	//	2 : call ShwoWindow( hwnd, SW_MAXIMIZE );
	//	3 : call MoveWindow( hwnd, ..., false ); to set restored position and size
	//
	//	Win8 or later : not smooth launch, use timer instead
	//	1 : WM_CREATE : read initial state value from INI or Registry
	//	2 : WM_CREATE : ShowWindow() with SW_HIDE
	//	3 : WM_CREATE : SetTimer()
	//	4 : WM_TIMER  : ShowWindow() with SW_NORMAL/SW_MAXIMIZE
	//	5 : WM_TIMER  : KillTimer()


	n_win w; n_win_zero( &w );


	// Status

	if ( IsIconic( hwnd ) )
	{
//n_win_text_set_literal( hwnd, "Minimized" );

		if ( w_ret != NULL ) { w_ret->state = SIZE_MINIMIZED; }

		return;

	} else
	if ( IsZoomed( hwnd ) )
	{
//n_win_text_set_literal( hwnd, "Maximized" );

		if ( w_ret != NULL )
		{

			// [!] : don't set .rc*

			RECT r; GetClientRect( hwnd, &r );

			w_ret->state = SIZE_MAXIMIZED;
			w_ret->csx   = r.right;
			w_ret->csy   = r.bottom;
			//w_ret->rcsx  = w.csx;
			//w_ret->rcsy  = w.csy;

		}

		return;

	} else {

		if ( mode & N_WIN_SET_RESTORE )
		{

			if ( w_ret != NULL )
			{
				w.state = w_ret->state;
			}

		} else {

			w.state = SIZE_RESTORED;

		}

	}


	// Calculation Pipeline

	bool is_win8   = n_sysinfo_version_8_or_later();
	bool is_win10  = n_sysinfo_version_10_or_later();


#ifdef _MSC_VER

	bool is_classic = n_win_style_is_classic();

	s32 dpi   = n_win_dpi( hwnd );
	s32 scale = dpi / 96;

#endif // #ifdef _MSC_VER


	// Style

	const DWORD   style =   n_win_style_get( hwnd );
	const DWORD exstyle = n_win_exstyle_get( hwnd );


	// Desktop

	s32 desktop_sx;
	s32 desktop_sy;

	n_win_desktop_size( &desktop_sx, &desktop_sy );


	// Scroll

	const s32 scroll_sx = GetSystemMetrics( SM_CXVSCROLL );
	const s32 scroll_sy = GetSystemMetrics( SM_CYHSCROLL );


	bool scrollx_onoff = false;
	bool scrolly_onoff = false;


	// [!] : non-client sizes : FIXEDFRAME = (EDGE + BORDER)

	s32 bar_sy   = 0;
	s32 frame_sx = 0;
	s32 frame_sy = 0;
	s32 nc_sx    = 0;
	s32 nc_sy    = 0;


	// [!] : WS_CAPTION = WS_BORDER | WS_DLGFRAME;

	if ( WS_CAPTION == ( WS_CAPTION & style ) )
	{

		if ( WS_THICKFRAME & style )
		{
//n_win_text_set_literal( hwnd, "SIZEFRAME" );

			frame_sx = GetSystemMetrics( SM_CXSIZEFRAME );
			frame_sy = GetSystemMetrics( SM_CYSIZEFRAME );

		} else {
//n_win_text_set_literal( hwnd, "FIXEDFRAME" );

			frame_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
			frame_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

		}

		// [!] : WS_EX_TOOLWINDOW has priority

		if ( WS_EX_TOOLWINDOW & exstyle )
		{
			bar_sy = GetSystemMetrics( SM_CYSMCAPTION );
		} else {
			bar_sy = GetSystemMetrics( SM_CYCAPTION   );
		}

	} else
	if ( WS_THICKFRAME & style )
	{

		frame_sx = GetSystemMetrics( SM_CXSIZEFRAME );
		frame_sy = GetSystemMetrics( SM_CYSIZEFRAME );

	} else
	if (
		( WS_DLGFRAME   & style )
		||
		( WS_EX_DLGMODALFRAME & exstyle )
	)
	{

		frame_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
		frame_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

	} else
	if ( WS_BORDER & style )
	{

		frame_sx = GetSystemMetrics( SM_CXBORDER );
		frame_sy = GetSystemMetrics( SM_CYBORDER );

	}// else

/*
	// [!] : Win10 build 10130 : not needed

	if ( is_win10 )
	{
		if ( WS_THICKFRAME & style )
		{
			frame_sx *= 2;
			frame_sy *= 2;
		}
	}
*/

	nc_sx =   ( frame_sx * 2 );
	nc_sy = ( ( frame_sy * 2 ) + bar_sy );


	// [!] : when DWM Composition (Aero Glass) is ON
	//
	//	close button will be set on upper of caption

	// [!] : Win10 Techcnical Preview : Build 9926
	//
	//	this patch isn't needed

	bool dwm_onoff = false;

#ifndef _MSC_VER

	if ( false == is_win10 )
	{
		dwm_onoff = n_win_dwm_is_on();
	}

#endif // #ifndef _MSC_VER

	s32 oy  = 0;
	s32 osy = 0;

	if ( dwm_onoff )
	{

		if ( WS_SIZEBOX & style )
		{
			oy = osy = GetSystemMetrics( SM_CYEDGE ) * 2;
		} else {
			oy = osy = frame_sy * 2;
		}

//n_win_hwndprintf_literal( hwnd, "Offset : %d %d", oy, osy );
	}


	// Taskbar

	int  taskbar_pos;
	RECT taskbar_rect;

	s32  desktop_fx = 0;
	s32  desktop_fy = 0;
	s32  desktop_tx = desktop_sx;
	s32  desktop_ty = desktop_sy;


	n_win_taskbarpos( &taskbar_pos, &taskbar_rect );

	if ( taskbar_pos == ABE_TOP )
	{
		desktop_fy = taskbar_rect.bottom;
	} else
	if ( taskbar_pos == ABE_BOTTOM )
	{
		desktop_ty = taskbar_rect.top;
	} else
	if ( taskbar_pos == ABE_LEFT )
	{
		desktop_fx = taskbar_rect.right;
	} else
	if ( taskbar_pos == ABE_RIGHT )
	{
		desktop_tx = taskbar_rect.left;
	}


	bool desktop_patch_onoff = false;
	s32  desktop_patch_sy    = 3;

#ifdef _MSC_VER

	// [x] : reason is unknown

	desktop_sy -= desktop_patch_sy;

#endif // #ifdef _MSC_VER


	// Current Position and Size

	w.csx = w.csy = 0;
	w.wsx = w.wsy = 0;

	{

		RECT r; GetWindowRect( hwnd, &r );

		n_win_rect_expand_size( &r, &w.posx, &w.posy, NULL, NULL );

	}

	{

		RECT r; GetClientRect( hwnd, &r );

		n_win_rect_expand_size( &r, NULL, NULL, &w.rcsx, &w.rcsy );

	}


	// Override

	if ( w_ret != NULL )
	{

		w.scrollx = w_ret->scrollx;
		w.scrolly = w_ret->scrolly;


		if ( mode & N_WIN_SET_NEEDPOS )
		{
//n_win_text_set_literal( hwnd, "Normal : Override : Position" );

			w.posx = w_ret->posx;
			w.posy = w_ret->posy;
		}

	}
	if ( rcsx >= 0 ) { w.rcsx = rcsx; }
	if ( rcsy >= 0 ) { w.rcsy = rcsy; }


	// Default Size

	// [!] : trick : ( w.rcsy + bar_sy ) < ( w.rcsy + nc_sy )

	w.csx = w.rcsx;
	w.csy = w.rcsy;
	w.wsx = w.rcsx + nc_sx;
	w.wsy = w.rcsy + nc_sy;

#ifdef _MSC_VER

	// [x] : reason is unknown

	if ( w.rcsx == desktop_sx ) { w.wsx += 2; }
	if ( w.rcsy == desktop_sy ) { w.wsy += 2; }

#endif // #ifdef _MSC_VER


	if ( mode & N_WIN_SET_CLIPPING )
	{

		if ( desktop_sx > w.rcsx )
		{ 

			scrollx_onoff = false;
			w.scrollx     = 0;

		} else {

			scrollx_onoff = true;


			// [!] : trick : minus value means "out of display"

			w.posx = desktop_fx - frame_sx;
			w.csx  = desktop_sx;
			w.wsx  = w.csx + nc_sx;

		}


		s32 tmp_rcsy;


		if ( dwm_onoff )
		{
			tmp_rcsy = ( w.rcsy +  nc_sy + oy );
		} else {
			tmp_rcsy = ( w.rcsy + bar_sy + oy );
		}


		if ( desktop_sy > tmp_rcsy )
		{
//n_win_text_set_literal( hwnd, "Scroll Y : Window" );

			scrolly_onoff = false;
			w.scrolly     = 0;


			// [!] : trick : ( w.rcsy + bar_sy ) < ( w.rcsy + nc_sy )
 
			w.csy  = w.rcsy;
			w.wsy  = w.rcsy + nc_sy;

		} else {

			desktop_patch_onoff = true;

			w.posy = desktop_fy - frame_sy;
			w.csy  = desktop_sy -   bar_sy;
			w.wsy  =      w.csy +    nc_sy;


			if ( dwm_onoff )
			{
				w.posy += oy;
				w.csy  -= osy;
				w.wsy  -= osy;

			}


			if ( w.rcsy > w.csy )
			{
//n_win_text_set_literal( hwnd, "Scroll Y : ON" );
				scrolly_onoff = true;
			} else {
//n_win_text_set_literal( hwnd, "Scroll Y : OFF" );
				scrolly_onoff = false;
			}

		}

	}


	// [Mechanism]
	//
	//	one more time! : a little bit complicated!
	//
	//	if SB_HORZ(left-right bar) => reduce bar size from client area y
	//	if window size gets more than desktop size by scrollbar size, also re-calculate

	if ( mode & N_WIN_SET_SCROLLBAR )
	{

		if (
			( scrollx_onoff )
			&&
			( scrolly_onoff )
		)
		{
//n_win_text_set_literal( hwnd, "Scroll : Both" );

			w.state = SIZE_MAXIMIZED;


			w.csx -= scroll_sx;
			w.csy -= scroll_sy;

		} else
		if ( scrollx_onoff )
		{
//n_win_text_set_literal( hwnd, "Scroll : X" );

			w.wsy += scroll_sy;

			if ( ( w.wsy - ( frame_sy * 2 ) ) > desktop_sy )
			{
//n_win_text_set_literal( hwnd, "Scroll : X : Both" );

				scrolly_onoff = true;


				w.state = SIZE_MAXIMIZED;


				desktop_patch_onoff = true;

				w.posy = desktop_fy - frame_sy;
				w.csy  = desktop_sy - bar_sy;
				w.wsy  = w.csy + nc_sy;


				if ( dwm_onoff )
				{

					w.posy += oy;
					w.csy  -= osy;
					w.wsy  -= osy;

				}


				w.csx -= scroll_sx;
				w.csy -= scroll_sy;

			}

		} else
		if ( scrolly_onoff )
		{
//n_win_text_set_literal( hwnd, "Scroll : Y" );

			w.wsx += scroll_sx;

			if ( ( w.wsx - nc_sx ) > desktop_sx )
			{
//n_win_text_set_literal( hwnd, "Scroll : Y : Both" );

				scrollx_onoff = true;


				w.state = SIZE_MAXIMIZED;


				w.posx = desktop_fx - frame_sx;
				w.csx  = desktop_sx; 
				w.wsx  = w.csx + nc_sx;


				w.csx -= scroll_sx;
				w.csy -= scroll_sy;

			}

		}


		// Scroll Position Clipper

		{

			s32 scrmax_x = w.rcsx - w.csx;
			s32 scrmax_y = w.rcsy - w.csy;

			if ( desktop_patch_onoff ) { scrmax_y += desktop_patch_sy; }

			if ( w.scrollx <        0 ) { w.scrollx =        0; }
			if ( w.scrolly <        0 ) { w.scrolly =        0; }
			if ( w.scrollx > scrmax_x ) { w.scrollx = scrmax_x; }
			if ( w.scrolly > scrmax_y ) { w.scrolly = scrmax_y; }

		}

	}


	if ( mode & N_WIN_SET_CENTERING )
	{

		if ( scrollx_onoff == false )
		{

			w.posx = desktop_fx + ( desktop_sx / 2 ) - ( w.wsx / 2 );

		}

		if ( scrolly_onoff == false )
		{

			w.posy = desktop_fy + ( desktop_sy / 2 ) - ( w.wsy / 2 );

			if ( dwm_onoff )
			{

				if ( WS_SIZEBOX & style )
				{
					w.posy += osy;
				} else {
					w.posy += frame_sy;
				}

			}

		}

	}

	if ( mode & N_WIN_SET_INNERPOS )
	{

		// [Needed] : border will be excluded

		if ( taskbar_pos != ABE_RIGHT )
		{
			int frame  = GetSystemMetrics( SM_CXSIZEFRAME );
			int border = GetSystemMetrics( SM_CXBORDER    );
			desktop_sx = GetSystemMetrics( SM_CXMAXIMIZED ) - ( frame + border );
			desktop_tx = desktop_sx;
		}


		// [!] : bottom-right first, top-left second

		if ( scrollx_onoff == false )
		{

			if ( ( w.posx + w.wsx ) > desktop_tx )
			{
				w.posx = desktop_fx + desktop_tx - w.wsx;
			}
			if ( w.posx < desktop_fx )
			{
				w.posx = desktop_fx;
			}

		}
		if ( scrolly_onoff == false )
		{

			if ( ( w.posy + w.wsy ) > desktop_ty )
			{
				w.posy = desktop_fy + desktop_ty - w.wsy;
			}
			if ( w.posy < desktop_fy )
			{
				w.posy = desktop_fy;
			}

		}

	}


	// Override

	s32 patch_sx  = 0;
	s32 patch_sy  = 0;

#ifdef _MSC_VER

	// [x] : reason is unknown : basic tweak

	// [!] : first level patch

	if ( WS_EX_DLGMODALFRAME & exstyle )
	{
		patch_sx += 10 * scale;
		patch_sy += 10 * scale;
	} else
	if ( WS_OVERLAPPEDWINDOW == ( WS_OVERLAPPEDWINDOW & style ) )
	{
		patch_sx +=  8 * scale;
		patch_sy +=  8 * scale;
	} else
	if ( WS_CAPTION == ( WS_CAPTION & style ) )
	{
		patch_sx += 10 * scale;
		patch_sy += 10 * scale;


		// [!] : second level patch : covering almost DPI settings

//n_win_hwndprintf_literal( hwnd, "%d %d", rcsx, desktop_sx );
		if ( w.rcsx >= desktop_sx )
		{
			w.posx = desktop_fx - ( 8 * scale );
		}
		if ( w.rcsy >= desktop_sy )
		{
			int n = 1;
			if ( is_classic ) { n = 8; }
			w.posy = desktop_fy - ( n * scale );
			w.csy  = w.csy - ( 4 * scale );
			w.wsy  = w.wsy - ( 4 * scale );
		}


		// [!] : third level patch : 200% or more support

		if ( scale != 1 )
		{

			if ( ( scrollx_onoff )&&( scrolly_onoff ) )
			{
				if ( ( taskbar_pos == ABE_TOP )||( taskbar_pos == ABE_BOTTOM ) )
				{
					patch_sx -= 3;
					patch_sy += 4;
				} else
				if ( taskbar_pos == ABE_LEFT )
				{
					patch_sx -= 3;
					patch_sy += 4;
					w.posx   += 3;
				} else
				if ( taskbar_pos == ABE_RIGHT )
				{
					patch_sy += 4;
				}
			} else
			if ( scrollx_onoff )
			{
				patch_sx += 4;
			} else
			if ( scrolly_onoff )
			{
				patch_sy += 4;
			}

		}

//n_win_hwndprintf_literal( hwnd, "%d", dpi );
		if ( dpi >= 192 )
		{
			// [!] : 200%

//n_win_hwndprintf_literal( hwnd, "%d %d", scrollx_onoff, scrolly_onoff );
			if ( ( scrollx_onoff )||( scrolly_onoff ) )
			{

				patch_sy -= 10;

				if (
					(
						( scrolly_onoff == false )
						||
						( ( scrollx_onoff )&&( scrolly_onoff ) )
					)
					&&
					( ( w.wsy - ( frame_sy * 2 ) ) > ( desktop_sy - desktop_patch_sy ) )
				)
				{
//n_win_hwndprintf_literal( hwnd, " %d %d ", w.wsy - ( frame_sy * 2 ), ( desktop_sy - desktop_patch_sy ) );

					w.posy = desktop_fy - frame_sy;
					w.csy  = desktop_sy - bar_sy;
					w.wsy  = w.csy + nc_sy;

					if ( dwm_onoff )
					{
						w.posy += oy;
						w.csy  -= osy;
						w.wsy  -= osy;
					}

					w.csy -= scroll_sy;


					patch_sy = 10 * scale; patch_sy -= 3;

				 	w.wsy -= 10;

				}

			}

		} else
		if ( dpi >= 168 )
		{
			// [!] : 175%

			if ( mode & N_WIN_SET_SCROLLBAR )
			{

				if ( ( scrollx_onoff )&&( scrolly_onoff ) )
				{

					w.csx -= 6;
					w.csy -= 5;

				} else
				if ( ( scrollx_onoff == false )&&( scrolly_onoff == false ) )
				{

					w.wsx += 8;
					w.csx += 8;

					w.wsy += 8;
					w.csy += 8;

				} else
				if ( ( scrollx_onoff == false )&&( scrolly_onoff ) )
				{

					w.csy -= 5;

				} else
				if ( ( scrollx_onoff )&&( scrolly_onoff == false ) )
				{

					//

				}

			}
		} else
		if ( dpi >= 144 )
		{
			// [!] : 150%

			patch_sy += 1;

			if ( ( taskbar_pos == ABE_LEFT )||( taskbar_pos == ABE_RIGHT ) )
			{
				if ( ( scrollx_onoff )&&( scrolly_onoff ) )
				{
					w.posx -= 4;
					w.wsx  += 8;
					w.csx  += 8;
				}
			}
		} else
		if ( dpi >= 120 )
		{
			// [!] : 125%

			patch_sy -= 1;

			if ( ( taskbar_pos == ABE_LEFT )||( taskbar_pos == ABE_RIGHT ) )
			{
				if ( ( scrollx_onoff )&&( scrolly_onoff ) )
				{
					w.posx -= 1;
					w.wsx  += 2;
					w.csx  += 2;
				}
			}
		} else {
			// [!] : 100%
//n_win_hwndprintf_literal( hwnd, " %d %d %d ", desktop_sy, w.wsy, frame_sy );

			if ( ( desktop_sy + frame_sy ) == ( w.wsy - frame_sy ) )
			{
				w.wsy -= 2;
			}

		}

	}

#endif // #ifdef _MSC_VER

	if ( w_ret != NULL )
	{

		if ( mode & N_WIN_SET_FORCEPOS )
		{
			w.posx = w_ret->posx;
			w.posy = w_ret->posy;
		}

	}

	s32 wsx = w.wsx + patch_sx;
	s32 wsy = w.wsy + patch_sy;

	if ( mode & N_WIN_SET_CALCONLY )
	{

		//

	} else
	if ( mode & N_WIN_SET_RESTORE )
	{
//n_posix_debug_literal( "" );

		// [!] : these solutions don't work
		//
		//	a : setting a style with WS_MAXIMIZE
		//	b : set sizes in CreateWindow()
		//	c : using SetWindowPlacement()

//n_win_hwndprintf_literal( hwnd, "%d", w.state );

		if ( w.state != SIZE_MAXIMIZED )
		{
#ifdef _MSC_VER
			if ( dpi >= 192 )
			{
				// [!] : 200%
			} else
			if ( dpi ==  96 )
			{
				// [!] : 100%
			} else {
				wsx += 6;
				wsy += 6;
			}
#endif // #ifdef _MSC_VER

			UINT swp = SWP_NOACTIVATE | SWP_DRAWFRAME;
			SetWindowPos( hwnd, NULL, w.posx,w.posy, wsx,wsy, swp );

			ShowWindow( hwnd, SW_NORMAL );

		} else {

			// [!] : Win8 : don't use ShowWindowAsync()
			// [!] : Win7 : DWM : ShowWindowAsync() is needed

			if ( is_win8 )
			{
				ShowWindow     ( hwnd, SW_MAXIMIZE );
			} else {
				ShowWindowAsync( hwnd, SW_MAXIMIZE );
			}

			MoveWindow( hwnd, w.posx,w.posy, wsx,wsy, false );

		}

	} else {

		UINT swp = SWP_NOACTIVATE | SWP_DRAWFRAME;

		SetWindowPos( hwnd, NULL, w.posx,w.posy, wsx,wsy, swp );

	}


	if ( w_ret != NULL ) { n_win_alias( &w, w_ret ); }


	return;
}

void
n_win_mbutton2centering_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( false == ( WS_CAPTION & n_win_style_get( hwnd ) ) ) { return; }


	switch( msg ) {


	case WM_NCMBUTTONDBLCLK :

		if ( HTCAPTION == LOWORD( wparam ) )
		{

			// [x] : if you don't move a cursor, WM_MBUTTONUP will happen in a client area

			s32 cursor_x, cursor_y; n_win_cursor_position( &cursor_x, &cursor_y );
 
			RECT r; GetWindowRect( hwnd, &r );
			s32 x,y,sx,sy; n_win_rect_expand_size( &r, &x,&y,&sx,&sy );
			s32 desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

			s32 cursor_rel_x = cursor_x - x;
			s32 cursor_rel_y = cursor_y - y;

			n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_CENTERING );

			SetCursorPos( w.posx + cursor_rel_x, w.posy + cursor_rel_y );

		}

	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_SET

