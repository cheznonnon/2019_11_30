// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [Mechanism] : Vista or later : How to prevent GDI handle leak
//
//	[ 1 ]
//	use a retuend icon of BM_SETIMAGE to destroy
//
//	[ 2 ]
//	a : use LR_SHARED with LoadImage()
//	b : use DestroyWindow( hgui ) at WM_CLOSE explicitly


// [x] : n_win_icon_resizer()
//
//	GCC4 : don't use optimization : this module will fail


// [!] : nonnon/com/IShellLink.c
//
//	you need to include IShellLink.c top of your code
//	com.c needs to be included at first
//
//	link is needed : see nonnon/com/com.c




#ifndef _H_NONNON_WIN32_WIN_ICON
#define _H_NONNON_WIN32_WIN_ICON




//#include "../../com/IShellLink.c"


#include "../sysinfo/drive.c"

#include "../registry.c"


// [!] : don't include bmp/all.c : for reducing EXE size

#include "../../neutral/bmp.c"
#include "../../neutral/bmp/_fastcopy.c"
#include "../../neutral/bmp/filter.c"
#include "../../neutral/bmp/transform.c"

#include "../../neutral/curico.c"
#include "../../neutral/png.c"

#include "../../neutral/ini.c"


#include "./commandline.c"




#include "./_debug.c"
#include "./bitmap.c"
#include "./message.c"




#include <shellapi.h>



//#pragma GCC push_options
//#pragma GCC optimize ( "O0" )




#define n_win_icon_maxcount( name ) (UINT) ExtractIcon( GetModuleHandle( NULL ), name, -1 )
//#define n_win_icon_maxcount( name ) ExtractIconEx( name, -1, NULL,NULL, 0 )

#define n_win_icon_exit( hicon ) DestroyIcon( hicon )

// internal
#ifdef __MINGW_H
__attribute__( ( optimize( "-O0" ) ) )
#endif // #ifdef 
void
n_win_icon_resizer( n_bmp *bmp, s32 sx, s32 sy, u32 color_margin )
{

	n_bmp to; n_bmp_zero( &to ); n_bmp_1st_fast( &to, sx,sy );


	// Box

	s32 x = 0;
	s32 y = 0;
	while( 1 )
	{

		n_bmp_ptr_set_fast( &to, x,y, color_margin );

		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	// Centering

	{

		s32 bmpsx = N_BMP_SX( bmp );
		s32 bmpsy = N_BMP_SY( bmp );

		s32 tx = ( sx - bmpsx ) / 2;
		s32 ty = ( sy - bmpsy ) / 2;

		n_bmp_fastcopy( bmp, &to, 0,0,sx,sy, tx,ty );

	}


	n_bmp_free_fast( bmp );
	n_bmp_alias( &to, bmp );


	return;
}

// internal
void
n_win_icon_grayscale( n_bmp *bmp, n_bmp *msk )
{

	if ( n_bmp_error( bmp ) ) { return; }


	u32 blend   = n_bmp_pal2rgb( GetSysColor( COLOR_BTNFACE ) );
	int blend_r = n_bmp_r( blend );
	int blend_g = n_bmp_g( blend );
	int blend_b = n_bmp_b( blend );


	s32 x,y,sx,sy;
	int a,r,g,b;
	u32 color;


	sx = N_BMP_SX( bmp );
	sy = N_BMP_SY( bmp );


	x = y = 0;
	while( 1 )
	{

		u32 mask; n_bmp_ptr_get_fast( msk, x,y, &mask );
		if ( 0 == n_bmp_r( mask ) )
		{

			n_bmp_ptr_get_fast( bmp, x,y, &color );


			// [!] : alpha is reserved

			a = n_bmp_a( color );
			r = n_bmp_r( color );
			g = n_bmp_g( color );
			b = n_bmp_b( color );

			r = g = b = ( r + g + b ) / 3;


			// [Patch] : grayscale will be grayscale

			r = ( r + blend_r ) / 2;
			g = ( g + blend_g ) / 2;
			b = ( b + blend_b ) / 2;

			color = n_bmp_argb( a,r,g,b );


			n_bmp_ptr_set_fast( bmp, x,y, color );

		}


		x++;
		if ( x >= sx )
		{

			x = 0;

			y++;
			if ( y >= sy ) { break; }
		}
	}


	return;
}

#define n_win_icon_hicon2bmp(     h, sx,sy, b,m ) n_win_icon_hicon2bmp_internal( h, sx,sy, b,m, false )
#define n_win_icon_hicon2bmp_1st( h, sx,sy, b,m ) n_win_icon_hicon2bmp_internal( h, sx,sy, b,m,  true )

void
n_win_icon_hicon2bmp_internal( HICON hicon, s32 sx, s32 sy, n_bmp *b, n_bmp *m, bool is_first )
{

	if ( hicon == NULL ) { return; }


	ICONINFO ii; ZeroMemory( &ii, sizeof( ICONINFO ) ); GetIconInfo( hicon, &ii );


	// [x] : Win9x : GetDIBits() : fail at WM_SETTINGCHANGE sometimes

	if ( is_first )
	{
		n_bmp_1st_fast( b, sx,sy ); 
		n_bmp_1st_fast( m, sx,sy ); 
	} else {
		n_bmp_new_fast( b, sx,sy ); 
		n_bmp_new_fast( m, sx,sy ); 
	}

	n_bmp_flush( b, n_bmp_black );
	n_bmp_flush( m, n_bmp_white );


	BITMAPINFO bi_b = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };
	BITMAPINFO bi_m = { N_BMP_INFOH( m ), { { 0,0,0,0 } } };


	HDC hdc = GetDC( NULL );


	// [Mechanism]
	//
	//	ii.hbmColor may have NULL
	//	then ii.hbmMask has the both bitmap with vertical offset

	if ( ii.hbmColor != NULL )
	{
//n_bmp_flush( b, n_bmp_rgb( 0,200,255 ) );
//n_bmp_flush( m, 0 );

		GetDIBits( hdc, ii.hbmColor, 0,sy, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		GetDIBits( hdc, ii.hbmMask,  0,sy, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

	} else {
//n_bmp_flush( b, n_bmp_rgb( 255,0,200 ) );
//n_bmp_flush( m, 0 );

		// [Mechanism] : this code is NT only available
		//
		//	bi.bmiHeader.biHeight *= 2;
		//
		//	GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		//	GetDIBits( hdc, ii.hbmMask, sy * 1,sy * 2, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

		bi_b.bmiHeader.biHeight *= 2;

		GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( b ), &bi_b, DIB_RGB_COLORS );
		GetDIBits( hdc, ii.hbmMask, sy * 0,sy * 1, N_BMP_PTR( m ), &bi_m, DIB_RGB_COLORS );

	}

	// [!] : Error Code
	//
	//	[ Win95 at WM_SETTINGCHANGE ]
	//
	//	OK : ERROR_INVALID_HANDLE	dec: 6 hex: 6
	//	NG : ERROR_INVALID_PARAMETER	dec:87 hex:57

/*
if( GetLastError() )
{
n_txt txt; n_txt_zero( &txt ); n_txt_new( &txt );
n_posix_char str[ 1024 ];
n_posix_sprintf_literal( str, "%ld %lx", GetLastError(), GetLastError() );
n_txt_add( &txt, 0, str );
n_txt_save( &txt, "ret.txt" );
n_txt_free( &txt );
}
*/

	ReleaseDC( NULL, hdc );


	n_win_bitmap_exit( ii.hbmColor );
	n_win_bitmap_exit( ii.hbmMask  );


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 )
	{
		if ( n_bmp_alpha_is_zero( b ) ) { n_bmp_alpha_reverse( b ); }
		if ( n_bmp_alpha_is_zero( m ) ) { n_bmp_alpha_reverse( m ); }
	}


	return;
}

HICON
n_win_icon_bmp2hicon( n_bmp *b, n_bmp *m )
{

	// [!] : the returned HICON needs n_win_icon_exit()


	const s32 sx = N_BMP_SX( m );
	const s32 sy = N_BMP_SY( m );


	if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 )
	{
		if ( n_bmp_alpha_is_visible( b ) ) { n_bmp_alpha_reverse( b ); }
	}


	HDC hdc = GetDC( NULL );


	// [!] : this code is NT only available
	//
	//	ii.hbmMask  = CreateDIBitmap( hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( m ), &bi, DIB_RGB_COLORS );


	BITMAPINFO bi = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };


	ICONINFO ii;

	ii.hbmColor = CreateDIBitmap( hdc, &bi.bmiHeader, CBM_INIT, N_BMP_PTR( b ), &bi, DIB_RGB_COLORS );
	ii.hbmMask  = CreateBitmap( sx, sy, 1, 1, NULL );


	{ // Mask for Chicago

		HDC     hdc_compat = CreateCompatibleDC( hdc );
		HBITMAP hbmp_old   = SelectObject( hdc_compat, ii.hbmMask );


		const COLORREF white = RGB( 255,255,255 );
		const COLORREF black = RGB(   0,  0,  0 );

		u32 color;

		s32 x = 0;
		s32 y = 0;
		while( 1 )
		{

			n_bmp_ptr_get_fast( m, x,y, &color );

			if ( color == n_bmp_white )
			{
				SetPixelV( hdc_compat, x,y, white );
			} else {
				SetPixelV( hdc_compat, x,y, black );
			}

			x++;
			if ( x >= sx )
			{

				x = 0;

				y++;
				if ( y >= sy ) { break; }
			}
		}


		SelectObject( hdc_compat, hbmp_old );
		DeleteDC( hdc_compat );

	} // Mask for Chicago


	ReleaseDC( NULL, hdc );


	HICON hicon = CreateIconIndirect( &ii );

	n_win_bitmap_exit( ii.hbmColor );
	n_win_bitmap_exit( ii.hbmMask  );

	return hicon;
}

HICON
n_win_icon_grayed( HICON hicon, s32 sx, s32 sy )
{

	// [!] : the returned HICON needs n_win_icon_exit()


	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );

	n_win_icon_hicon2bmp_1st( hicon, sx, sy, &b, &m );

	n_win_icon_grayscale( &b, &m );

	HICON hicon_gray = n_win_icon_bmp2hicon( &b, &m );

	n_bmp_free_fast( &b );
	n_bmp_free_fast( &m );


	return hicon_gray;
}

#define n_win_icon_ExtractAssociatedIcon( name, index ) n_win_icon_ExtractAssociatedIcon_fast( name, index, false )

HICON
n_win_icon_ExtractAssociatedIcon_fast( n_posix_char *icon_name, int icon_index, bool is_allocated )
{

	// [x] : ExtractAssociatedIconA() on WinNT
	//
	//	crash when using a string literal

	HINSTANCE hinst = GetModuleHandle( NULL );
	WORD      word  = icon_index;
	HICON     hicon = NULL;

	if ( is_allocated )
	{

		hicon = ExtractAssociatedIcon( hinst, icon_name, &word );

	} else {

		n_posix_char *s = n_string_carboncopy( icon_name );

		hicon = ExtractAssociatedIcon( hinst, s, &word );

		n_string_free( s );

	}


	return hicon;
}

typedef struct
{

	n_posix_char *name;
	int           index;
	int           count;
	bool          found;

} n_win_icon_load_from_resource_struct;

BOOL CALLBACK
n_win_icon_load_from_resource_EnumResNameProc( HMODULE hModule, LPCTSTR lpszType, LPTSTR lpszName, LONG_PTR lParam )
{

	n_win_icon_load_from_resource_struct *nwilfrs = (void*) lParam;


	// [Needed] : GDB : Segmentation Fault : at n_posix_strlen()

	if ( IS_INTRESOURCE( lpszName ) )
	{
//n_posix_debug_literal( " %d ", (int) lpszName );

		//return false;

		if ( nwilfrs->count == nwilfrs->index )
		{

			nwilfrs->name  = NULL;
			nwilfrs->index = (int) lpszName;
			nwilfrs->found = true;

			return false;
		}

	} else {

		if ( nwilfrs->count == nwilfrs->index )
		{
//n_posix_debug_literal( " Found : %s ", lpszName );
			nwilfrs->name  = n_string_carboncopy( lpszName );
			nwilfrs->found = true;

			return false;
		}

	}

	nwilfrs->count++;


	return true;
}

#define n_win_icon_load_from_resource_1st( n, i, s, b, m ) n_win_icon_load_from_resource_internal( n, i, s, b, m,  true )
#define n_win_icon_load_from_resource(     n, i, s, b, m ) n_win_icon_load_from_resource_internal( n, i, s, b, m, false )

bool
n_win_icon_load_from_resource_internal
(
	const n_posix_char *name,
	      int           index,
	      int           size,
	      n_bmp        *bmp,
	      n_bmp        *msk,
              bool          is_first
)
{

	if ( n_string_is_empty( name ) ) { return true; }

	if ( is_first == false )
	{
		n_bmp_free( bmp );
		n_bmp_free( msk );
	}

	if ( bmp == NULL ) { return true; }
	if ( msk == NULL ) { return true; }


#pragma pack( push, 2 )

	typedef struct
	{

		BYTE   bWidth;
		BYTE   bHeight;
		BYTE   bColorCount;
		BYTE   bReserved;
		WORD   wPlanes;
		WORD   wBitCount;
		DWORD  dwBytesInRes;
		WORD   nID;

	} GRPICONDIRENTRY, *LPGRPICONDIRENTRY;

	typedef struct 
	{

		WORD            idReserved;
		WORD            idType;
		WORD            idCount;
		GRPICONDIRENTRY idEntries[ 1 ];

	} GRPICONDIR, *LPGRPICONDIR;

#pragma pack( pop )

	typedef struct
	{

		BITMAPINFOHEADER icHeader;
		RGBQUAD          icColors[ 1 ];
		BYTE             icXOR   [ 1 ];
		BYTE             icAND   [ 1 ];

	} ICONIMAGE, *LPICONIMAGE;

	typedef struct
	{

		int index;
		int size;
		int bit;

	} n_sort;


	HMODULE hmod = LoadLibraryEx( name, NULL, LOAD_LIBRARY_AS_DATAFILE );
	if ( hmod == NULL )
	{
//n_posix_debug_literal( " LoadLibraryEx() : %s ", name );
		return true;
	}


	// [x] : some icons' order is different from ExtractIcon()

	n_posix_char str_index[ 100 ];
	if ( index < 0 )
	{
		n_posix_sprintf_literal( str_index, "#%d", index * -1 );
	} else {
		n_posix_sprintf_literal( str_index, "#%d", index +  1 );
	}
	HRSRC hrsrc = FindResource( hmod, str_index, RT_GROUP_ICON );

	if ( hrsrc == NULL )
	{
//if ( n_string_is_same_literal( "C:\\windows\\system32\\wscript.exe", name ) ) { n_debug = true; }
		n_win_icon_load_from_resource_struct nwilfrs = { NULL, index, 0, false };

		EnumResourceNames( hmod, RT_GROUP_ICON, n_win_icon_load_from_resource_EnumResNameProc, (LONG_PTR) &nwilfrs );

		if ( nwilfrs.found )
		{
			if ( nwilfrs.name != NULL )
			{
				hrsrc = FindResource( hmod, nwilfrs.name, RT_GROUP_ICON );
				n_string_free( nwilfrs.name );
			} else {
				n_posix_sprintf_literal( str_index, "#%d", nwilfrs.index );
				hrsrc = FindResource( hmod,    str_index, RT_GROUP_ICON );
			}
		}

	}

	if ( hrsrc == NULL )
	{
//n_posix_debug_literal( " FindResource() " );

		FreeLibrary( hmod );

		return true;
	}


	HGLOBAL hglbl = LoadResource( hmod, hrsrc );
	if ( hglbl == NULL )
	{
//n_posix_debug_literal( " LoadResource() : %s ", name );

		FreeLibrary( hmod );

		return true;
	}


	GRPICONDIR *grpicondir = LockResource( hglbl );
	if ( grpicondir == NULL )
	{
//n_posix_debug_literal( " LockResource() " );

		FreeLibrary( hmod );

		return true;
	}


	if ( grpicondir->idCount == 0 )
	{
//n_posix_debug_literal( " if ( grpicondir->idCount == 0 ) " );

		FreeLibrary( hmod );

		return true;
	}


	int i = 0;
	while( 1 )
	{break;

		if ( i >= grpicondir->idCount ) { break; }

		s32 sx  = grpicondir->idEntries[ i ].bWidth;
		s32 sy  = grpicondir->idEntries[ i ].bHeight;
		int cb  = grpicondir->idEntries[ i ].dwBytesInRes;
		int clr = grpicondir->idEntries[ i ].bColorCount;
		int bit = grpicondir->idEntries[ i ].wBitCount;

		if ( sx == 0 ) { sx = 256; }
		if ( sy == 0 ) { sy = 256; }

n_posix_debug_literal
(
	" Size %dx%d : Color %d : Bit %d : %d byte ",
	sx, sy,
	clr,
	bit,
	cb
);

		i++;

	}


	n_sort *sort = n_memory_new( grpicondir->idCount * sizeof( n_sort ) );

	{
		int i = 0;
		while( 1 )
		{

			if ( i >= grpicondir->idCount ) { break; }

			sort[ i ].index = i;
			sort[ i ].size  = grpicondir->idEntries[ i ].bWidth;
			sort[ i ].bit   = grpicondir->idEntries[ i ].wBitCount;

			if ( sort[ i ].size == 0 ) { sort[ i ].size = 256; }

			i++;

		}
	}


	if ( 1 < grpicondir->idCount )
	{

		int i = 0;
		int j = i + 1;
		while( 1 )
		{//break;

			s32 fsx = sort[ i ].size;
			s32 tsx = sort[ j ].size;

			s32 f   = sort[ i ].bit;
			s32 t   = sort[ j ].bit;

			if ( ( fsx < tsx )||( f < t ) )
			{
				n_sort swap      = sort[ i ];
				       sort[ i ] = sort[ j ];
				       sort[ j ] = swap;
			}

			j++;
			if ( j >= grpicondir->idCount )
			{
				i++;
				if ( i >= grpicondir->idCount ) { break; }

				j = i + 1;
				if ( j >= grpicondir->idCount ) { break; }
			}

		}

	}


	bool is_found     = false;
	bool resize_onoff = false;

	//int  index_256px  =    -1;
	//bool shrink_onoff = false;

	i = 0;
	while( 1 )
	{

		if ( i >= grpicondir->idCount ) { break; }

		s32 sx = sort[ i ].size;
//n_posix_debug_literal( " %d ", sx );

		//if ( sx == 256 ) { index_256px = i; }

		if ( size == sx )
		{
			is_found = true;
			break;
		}

		i++;

	}
/*
	if ( is_found == false )
	{
		if ( ( size >= 64 )&&( index_256px != -1 ) )
		{
			i            = index_256px;
			is_found     = true;
			shrink_onoff = true;
		}
	}
*/
	if ( is_found == false )
	{

		i = 0;
		while( 1 )
		{

			if ( i >= grpicondir->idCount ) { break; }

			s32 sx = sort[ i ].size;
//n_posix_debug_literal( " %d ", sx );

			if ( size > sx )
			{
				is_found     = true;
				resize_onoff = true;

				break;
			}

			i++;

		}

	}

	int target = 0;
	if ( i < grpicondir->idCount ) { target = sort[ i ].index; }


	n_memory_free( sort );


	if ( is_found == false )
	{
//n_posix_debug_literal( " Not Found : %s ", name );

		FreeLibrary( hmod );

		return true;
	}


	int id = grpicondir->idEntries[ target ].nID;
	s32 sx = grpicondir->idEntries[ target ].bWidth;
	s32 sy = grpicondir->idEntries[ target ].bHeight;
	int cb = grpicondir->idEntries[ target ].dwBytesInRes;

	if ( sx == 0 ) { sx = 256; }
	if ( sy == 0 ) { sy = 256; }
//n_posix_debug_literal( " %d ", sx );


	hrsrc = FindResource( hmod, MAKEINTRESOURCE( id ), RT_ICON );
	hglbl = LoadResource( hmod, hrsrc );

	ICONIMAGE *ii = LockResource( hglbl );

//n_posix_debug_literal( " %d ", ii->icHeader.biSize );

	if ( ii->icHeader.biSize != N_BMP_SIZE_INFOH )
	{
//n_posix_debug_literal( " PNG Icon " );

		if ( false )//( n_sysinfo_version_vista_or_later() )
		{

			// [!] : WinXP or earlier : not supported

			DWORD byte = SizeofResource( hmod, hrsrc );
			UINT    lr = LR_DEFAULTCOLOR | LR_DEFAULTSIZE;
			HICON hico = CreateIconFromResourceEx( (void*) ii, byte, true, 0x00030000, sx,sy, lr );

			n_win_icon_hicon2bmp( hico, sx,sy, bmp, msk );

		} else {
//n_posix_debug_literal( " %d %d ", cb, SizeofResource( hmod, hrsrc ) );

			n_png png; n_png_zero( &png );
			n_png_load_onmemory( &png, (void*) ii, cb );
			n_png_uncompress( &png, bmp );

			n_bmp_new( msk, sx,sy );

		}

	} else {

		n_memory_copy( &ii->icHeader, &N_BMP_INFOH( bmp ), N_BMP_SIZE_INFOH );
//n_posix_debug_literal( " %d %d : %d ", N_BMP_SX( bmp ), N_BMP_SY( bmp ), N_BMP_DEPTH( bmp ) );
//n_posix_debug_literal( " %d ", N_BMP_CBSIZE( bmp ) );
//n_posix_debug_literal( " %d ", N_BMP_PAL( bmp ) );
//n_posix_debug_literal( " %d ", N_BMP_RLE( bmp ) );

		// [!] : magic calculation

		int offset = -4;


		// [!] : index color mode : palette zero is special

		if ( ( 8 >= N_BMP_DEPTH( bmp ) )&&( 0 == N_BMP_PAL( bmp ) ) )
		{

			if ( 1 == N_BMP_DEPTH( bmp ) ) { N_BMP_PAL( bmp ) =   2; } else
			if ( 4 == N_BMP_DEPTH( bmp ) ) { N_BMP_PAL( bmp ) =  16; } else
			if ( 8 == N_BMP_DEPTH( bmp ) ) { N_BMP_PAL( bmp ) = 256; }

		}


		if ( 0 != N_BMP_PAL( bmp ) )
		{

			int pal_byte = N_BMP_PAL( bmp ) * sizeof( u32 );
			N_BMP_PTR_PAL( bmp ) = n_memory_new( pal_byte );
			n_memory_copy( ii->icColors, N_BMP_PTR_PAL( bmp ), pal_byte );
//n_posix_debug_literal( " %d ", pal_byte );


			offset += pal_byte;

		}


		N_BMP_SY( bmp ) /= 2;

				
		void   *ptr_bmp  = (void*) &ii->icXOR[ offset ];
		size_t  ptr_byte = n_bmp_size( N_BMP_SX( bmp ), N_BMP_SY( bmp ), N_BMP_DEPTH( bmp ) );

		if ( 0 != N_BMP_PAL( bmp ) )
		{

			N_BMP_PTR( bmp ) = n_memory_new( ptr_byte );
			n_memory_copy( ptr_bmp, N_BMP_PTR( bmp ), ptr_byte );

			n_bmp_pal2full( bmp );

		} else
		if ( 24 == N_BMP_DEPTH( bmp ) )
		{

			N_BMP_PTR( bmp ) = n_memory_new( ptr_byte );
			n_memory_copy( ptr_bmp, N_BMP_PTR( bmp ), ptr_byte );
			n_bmp_32bit( bmp );

		} else {

			// [Needed] : n_bmp_precalc() is needed

			N_BMP_PTR( bmp ) = n_memory_new( ptr_byte );
			n_memory_copy( ptr_bmp, N_BMP_PTR( bmp ), ptr_byte );

			n_bmp_precalc( bmp );

			//n_bmp_new( bmp, N_BMP_SX( bmp ), N_BMP_SY( bmp ) );
			//n_memory_copy( ptr_bmp, N_BMP_PTR( bmp ), N_BMP_SIZE( bmp ) );
//n_bmp_save_literal( bmp, "debug.bmp" );

		}

		if ( N_BMP_ALPHA_CHANNEL_VISIBLE == 255 )
		{
			if ( n_bmp_alpha_is_zero( bmp ) ) { n_bmp_alpha_reverse( bmp ); }
		}


		void *ptr_msk = (void*) &ii->icXOR[ offset + ptr_byte ];

		n_curico_mask_decode( bmp, ptr_msk );

		N_BMP_RLE  ( msk ) = 0;
		N_BMP_SX   ( msk ) = N_BMP_SX( bmp );
		N_BMP_SY   ( msk ) = N_BMP_SY( bmp );
		N_BMP_DEPTH( msk ) = 1;
		N_BMP_PAL  ( msk ) = 2;

		int msk_pal_byte = N_BMP_PAL( msk ) * sizeof( u32 );
		N_BMP_PTR_PAL( msk ) = n_memory_new( msk_pal_byte );
		N_BMP_PTR_PAL( msk )[ 0 ] = n_bmp_black;
		N_BMP_PTR_PAL( msk )[ 1 ] = n_bmp_white;

		size_t msk_byte = n_bmp_size( N_BMP_SX( msk ), N_BMP_SY( msk ), 1 );
		N_BMP_PTR( msk ) = n_memory_new( msk_byte );
		n_memory_copy( ptr_msk, N_BMP_PTR( msk ), msk_byte );
		n_bmp_pal2full( msk );

	} // if ( ii->icHeader.biSize != N_BMP_SIZE_INFOH )


	if ( resize_onoff )
	{

		int ratio = size / N_BMP_SX( bmp );
		n_bmp_scaler_big( bmp, ratio );
		n_bmp_scaler_big( msk, ratio );

		n_win_icon_resizer( bmp, size,size, n_bmp_black );
		n_win_icon_resizer( msk, size,size, n_bmp_white );

	}
/*
	if ( shrink_onoff )
	{

		int ratio = 256 / size;

		n_bmp_smoothshrink( bmp, ratio + 1 );
		n_bmp_smoothshrink( msk, ratio + 1 );

		n_win_icon_resizer( bmp, size,size, n_bmp_black );
		n_win_icon_resizer( msk, size,size, n_bmp_white );

	}
*/

	FreeLibrary( hmod );


	return false;
}

#define N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK ( 2 )

void
n_win_icon_name_resolve( const n_posix_char *name, n_posix_char *ret_name, int *ret_index, bool *is_lnk )
{

	if ( n_string_path_is_drivename( name ) )
	{

		u32 type = n_sysinfo_drive_type( name );

		if ( n_sysinfo_version_vista_or_later() )
		{

			n_string_copy_literal( "imageres.dll", ret_name );

			if ( type == DRIVE_REMOVABLE )
			{
				(*ret_index) = 31 + 3;
			} else
			if ( type == DRIVE_CDROM     )
			{
				(*ret_index) = 25 + 4;
			} else {

				n_posix_char sys_f[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
				n_posix_char sys_t[ N_REGISTRY_ASSOCIATION_CCH_MAX ];

				n_string_copy_literal( "%SystemDrive%", sys_f );
				ExpandEnvironmentStrings( sys_f, sys_t, N_REGISTRY_ASSOCIATION_CCH_MAX );
				n_posix_strcat( sys_t, N_POSIX_SLASH );
//n_posix_debug_literal( "%s : %s", name, sys_t );

				if ( n_string_is_same( name, sys_t ) )
				{
					(*ret_index) = 32 + 3;
				} else {
					(*ret_index) = 27 + 4;
				}

			}

		} else {

			n_string_copy_literal( "shell32.dll", ret_name );

			if ( type == DRIVE_REMOVABLE )
			{
				(*ret_index) =  7;
			} else
			if ( type == DRIVE_CDROM     )
			{
				(*ret_index) = 11;
			} else {
				(*ret_index) =  8;
			}

		}

		return;
	}


	int          cch = N_REGISTRY_ASSOCIATION_CCH_MAX;
	int          cb  = cch * sizeof( n_posix_char );
	n_posix_char exp[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( exp );
	n_posix_char ico[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( ico );
	n_posix_char def[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( def );


#ifdef _H_NONNON_WIN32_COM_ISHELLLINK

	n_posix_char *path = NULL;

	if ( n_IShellLink_is_shortcut( name ) )
	{
		path = n_string_new( N_ISHELLLINK_LNK2PATH_CCH_PATH );

		n_IShellLink_lnk2path( name, path, NULL, ret_name, ret_index );
//n_posix_debug_literal( "name : %s\npath : %s\nret : %s : %d", name, path, ret_name, *ret_index );
		if ( is_lnk != NULL ) { (*is_lnk) = true; }

		if ( false == n_posix_stat_is_exist( path ) )
		{
//n_posix_debug_literal( " %s ", path );
			n_string_truncate( path );
			n_string_truncate( ret_name );
			(*ret_index) = 0;
		}
	} else {
		path = n_string_alloccopy( N_ISHELLLINK_LNK2PATH_CCH_PATH, name );
		if ( is_lnk != NULL )
		{
			DWORD dw = GetFileAttributes( name );
			if ( ( dw != 0xffffffff )&&( dw & FILE_ATTRIBUTE_REPARSE_POINT ) )
			{
				(*is_lnk) = N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK;
			}
		}
	}

#else  // #ifdef _H_NONNON_WIN32_COM_ISHELLLINK

	n_posix_char *path = n_string_carboncopy( name );

#endif // #ifdef _H_NONNON_WIN32_COM_ISHELLLINK


//n_posix_debug_literal( "Path : %s", path );

	if ( n_posix_stat_is_file( path ) )
	{

		n_posix_char typ[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( typ );

		n_posix_char *ext = n_string_path_ext_get_new( path );
		n_registry_read( HKEY_CLASSES_ROOT, ext, N_STRING_EMPTY, typ, cb );
		n_string_path_free( ext );

		n_posix_sprintf_literal( ico, "%s\\DefaultIcon", typ );
		n_registry_read( HKEY_CLASSES_ROOT, ico, N_STRING_EMPTY, exp, cb );

		ExpandEnvironmentStrings( exp, def, N_REGISTRY_ASSOCIATION_CCH_MAX );

	} else
	if ( n_posix_stat_is_dir( path ) )
	{

		if ( n_sysinfo_version_vista_or_later() )
		{

			n_posix_char usr[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( usr );
			ExpandEnvironmentStrings( n_posix_literal( "%USERPROFILE%" ), usr, N_REGISTRY_ASSOCIATION_CCH_MAX );

			if ( n_string_is_same( name, usr ) )
			{
				int index_user = 117 + 5;
				n_posix_sprintf_literal( exp, "imageres.dll,%d", index_user );
			}

		}

		n_posix_char *ini_name = NULL;
		if ( n_string_is_empty( exp ) )
		{
			ini_name = n_string_path_make_new( name, n_posix_literal( "desktop.ini" ) );
		}

		if ( n_posix_stat_is_exist( ini_name ) )
		{
			n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, ini_name );


			n_posix_char *ini_section = n_posix_literal( ".ShellClassInfo" );


			// [!] : new scheme

			n_posix_char *ini_lval = n_posix_literal( "IconResource" );
			n_ini_value_str( &ini, ini_section, ini_lval, N_STRING_EMPTY, exp, cch );


			if ( n_string_is_empty( exp ) )
			{
				// [!] : old scheme

				n_posix_char str[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( str );

				n_posix_char *ini_lval_name  = n_posix_literal( "IconFile" );
				n_posix_char *ini_lval_index = n_posix_literal( "IconIndex" );
				n_ini_value_str( &ini, ini_section, ini_lval_name , N_STRING_EMPTY, exp, cch );
				n_ini_value_str( &ini, ini_section, ini_lval_index, N_STRING_EMPTY, str, cch );

				if ( false == n_string_is_empty( exp ) )
				{
					n_posix_sprintf_literal( exp, "%s,%d", exp, n_posix_atoi( str ) );
				}
			}


			n_ini_free( &ini );
		}

		if ( n_string_is_empty( exp ) )
		{
			n_posix_sprintf_literal( ico, "%s", n_posix_literal( "Folder\\DefaultIcon" ) );
			n_registry_read( HKEY_CLASSES_ROOT, ico, N_STRING_EMPTY, exp, cb );
		}
		n_string_path_free( ini_name );

		ExpandEnvironmentStrings( exp, def, N_REGISTRY_ASSOCIATION_CCH_MAX );

	}


//n_posix_debug_literal( "%s\n%s", exp, def );


	if ( n_string_is_empty( def ) )
	{
		if ( n_sysinfo_version_vista_or_later() )
		{
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
			if ( ret_index != NULL ) { (*ret_index) = -2; }
		} else {
			n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "shell32.dll"  ) );
			if ( ret_index != NULL ) { (*ret_index) =  0; }
		}
	} else
	if ( n_string_is_same_literal( "%1", def ) )
	{
		n_posix_sprintf_literal( ret_name, "%s", path );
//n_posix_debug_literal( "%s", ret_name );

		if ( 0 == n_win_icon_maxcount( ret_name ) )
		{
			if ( n_sysinfo_version_vista_or_later() )
			{
				n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "imageres.dll" ) );
				if ( ret_index != NULL ) { (*ret_index) = 11 + 3; }
			} else {
				n_posix_sprintf_literal( ret_name, "%s", n_posix_literal( "shell32.dll"  ) );
				if ( ret_index != NULL ) { (*ret_index) = 2;      }
			}
		}
	} else {
		n_posix_char str_index[ N_REGISTRY_ASSOCIATION_CCH_MAX ];
		n_string_parameter( def, N_STRING_COMMA, N_STRING_EMPTY, 0, ret_name  );
		n_string_parameter( def, N_STRING_COMMA, N_STRING_EMPTY, 1, str_index );
		if ( ret_index != NULL ) { (*ret_index) = n_posix_atoi( str_index ); }
//n_posix_debug_literal( "Ret : %s : %d", ret_name, (*ret_index) );
	}
//n_posix_debug_literal( "Ret : %s", ret_name );

	n_string_free( path );


	return;
}

// internal
void
n_win_icon_linkarrow( n_bmp *b, n_bmp *m, int size )
{

	// [!] : is_first only

	if ( n_sysinfo_version_vista_or_later() )
	{
		n_win_icon_load_from_resource_1st( n_posix_literal( "imageres.dll" ), 154 + 8, size, b, m );
	} else {
		n_win_icon_load_from_resource_1st( n_posix_literal(  "shell32.dll" ),      29, size, b, m );
	}


	return;
}

#define N_WIN_ICON_INIT_OPTION_DEFAULT      ( 0 << 0 )
#define N_WIN_ICON_INIT_OPTION_RESOURCE     ( 1 << 0 )
#define N_WIN_ICON_INIT_OPTION_NAME_RESOLVE ( 1 << 1 )

#define n_win_icon_init_large( s, i, opt ) n_win_icon_init_internal( s, i, NULL,NULL,  true, opt )
#define n_win_icon_init_small( s, i, opt ) n_win_icon_init_internal( s, i, NULL,NULL, false, opt )

#define n_win_icon_init_bmp( s, i, b,m, opt ) n_win_icon_init_internal( s, i, b,m, true, opt )

#define n_win_icon_init(         s, i, opt ) n_win_icon_init_large( s, i, opt )
#define n_win_icon_init_literal( s, i, opt ) n_win_icon_init( n_posix_literal( s ), i, opt )

static u32 n_win_icon_init_link_color_bg = n_bmp_white_invisible;
static int n_win_icon_init_stop          = 0;

#define N_WIN_ICON_INIT_RESOURCE_SIZE_AUTO ( -1 )
static int n_win_icon_init_resource_size = N_WIN_ICON_INIT_RESOURCE_SIZE_AUTO;

// internal
HICON
n_win_icon_init_internal( n_posix_char *icon_name, int icon_index, n_bmp *bmp, n_bmp *msk, bool is_large, int option )
{

	// [!] : the returned HICON needs n_win_icon_exit()


	s32 fsx,fsy, tsx,tsy;

	if ( is_large )
	{
		fsx = 32;
		fsy = 32;
		tsx = GetSystemMetrics( SM_CXICON );
		tsy = GetSystemMetrics( SM_CYICON );
	} else {
		fsx = 16;
		fsy = 16;
		tsx = GetSystemMetrics( SM_CXSMICON );
		tsy = GetSystemMetrics( SM_CYSMICON );
	}

	if ( n_win_icon_init_resource_size == N_WIN_ICON_INIT_RESOURCE_SIZE_AUTO )
	{

		int step = 8;
		while( 1 )
		{

			if ( fsx >= ( tsx - n_win_icon_init_stop ) ) { break; }

			fsx += step;
			fsy += step;

		}

	} else {

		fsx = fsy = tsx = tsy = n_win_icon_init_resource_size;

	}
//n_posix_debug_literal( "%d:%d", fsx,fsy );


	HICON hicon = NULL;

	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );


	// [!] : for performance

	bool fallback = true;
	bool is_lnk   = false;

	if ( option & N_WIN_ICON_INIT_OPTION_RESOURCE )
	{

		if ( option & N_WIN_ICON_INIT_OPTION_NAME_RESOLVE )
		{

			n_posix_char resolve_name[ N_REGISTRY_ASSOCIATION_CCH_MAX ]; n_string_truncate( resolve_name );
			int          resolve_index = icon_index;

			if ( icon_name == NULL )
			{
				n_posix_char *name = n_win_exepath_new();
				n_win_icon_name_resolve(      name, resolve_name, &resolve_index, &is_lnk );
				n_string_path_free( name );
			} else {
				n_win_icon_name_resolve( icon_name, resolve_name, &resolve_index, &is_lnk );
			}

			fallback = n_win_icon_load_from_resource_1st( resolve_name, resolve_index, fsx, &b, &m );

		} else {

			if ( icon_name == NULL )
			{
				n_posix_char *name = n_win_exepath_new();
				fallback = n_win_icon_load_from_resource_1st(      name, icon_index, fsx, &b, &m );
				n_string_path_free( name );
			} else {
				fallback = n_win_icon_load_from_resource_1st( icon_name, icon_index, fsx, &b, &m );
			}

		}

	}

//fallback = false;
	if ( fallback )
	{

		// [!] : Vista or later : LR_SHARED + DestroyWindow() only prevents GDI handle leak

		n_posix_char *name = NULL;

		if ( icon_name == NULL )
		{
			name = n_win_exepath_new();
		}

		if ( hicon == NULL )
		{
			const HINSTANCE hinst = GetModuleHandle( NULL );
			UINT lr = LR_DEFAULTCOLOR | LR_SHARED;

			if ( icon_name == NULL )
			{
				hicon = LoadImage( hinst,      name, IMAGE_ICON, fsx,fsy, lr );
			} else {
				hicon = LoadImage( hinst, icon_name, IMAGE_ICON, fsx,fsy, lr );
			}

		}
		if ( hicon == NULL )
		{

			const HINSTANCE hinst = GetModuleHandle( NULL );

			if ( icon_name == NULL )
			{
				hicon = ExtractIcon( hinst,      name, icon_index );
			} else {
				hicon = ExtractIcon( hinst, icon_name, icon_index );
			}

		}
		if ( hicon == NULL )
		{

			if ( icon_name == NULL )
			{
				hicon = n_win_icon_ExtractAssociatedIcon_fast(      name, icon_index,  true );
			} else {
				hicon = n_win_icon_ExtractAssociatedIcon_fast( icon_name, icon_index, false );
			}

		}

		if ( icon_name == NULL )
		{
			n_string_path_free( name );
		}

		if ( hicon == NULL ) { return NULL; }


		// [!] : for performance

		if ( bmp == NULL )
		{
			if ( ( fsx == tsx )&&( fsy == tsy ) )
			{
				return hicon;
			}
		}

//if ( ii.hbmColor == NULL ) { n_win_icon_exit( hicon ); return NULL; }
//if ( ii.hbmMask  == NULL ) { n_win_icon_exit( hicon ); return NULL; }


		n_win_icon_hicon2bmp_1st( hicon, tsx,tsy, &b, &m );

		if ( fsx < tsx )
		{
//n_posix_debug_literal( "%s", icon_name );
			double ratio = (double) fsx / tsx;
			n_bmp_resampler( &b, ratio,ratio );
			n_bmp_resampler( &m, ratio,ratio );
		}

	}


	int ratio = tsx / fsx;
	n_bmp_scaler_big( &b, ratio );
	n_bmp_scaler_big( &m, ratio );

	n_win_icon_resizer( &b, tsx,tsy, n_bmp_black );
	n_win_icon_resizer( &m, tsx,tsy, n_bmp_white );


	if ( ( fallback == false )&&( is_lnk ) )
	{

		n_bmp b_arrow; n_bmp_zero( &b_arrow );
		n_bmp m_arrow; n_bmp_zero( &m_arrow );

		n_win_icon_linkarrow( &b_arrow, &m_arrow, tsx );
//n_bmp_save_literal( &b_arrow, "./b_arrow.bmp" );

		if ( is_lnk == N_WIN_ICON_NAME_RESOLVE_SYMBOLIC_LINK )
		{
			s32 x = 0;
			s32 y = 0;
			while( 1 )
			{

				u32 color; n_bmp_ptr_get_fast( &b_arrow, x, y, &color );
				if ( ( color != n_bmp_black )&&( color != n_bmp_black_invisible ) )
				{
					//color = n_bmp_blend_pixel( color, n_gdi_systemcolor( COLOR_HIGHLIGHT ), 0.25 );
					color = n_bmp_hue_wheel_tweak_pixel( color, 64 );
					n_bmp_ptr_set_fast( &b_arrow, x, y, color );
				}

				x++;
				if ( x >= N_BMP_SX( &m_arrow ) )
				{
					x = 0;

					y++;
					if ( y >= N_BMP_SY( &m_arrow ) ) { break; }
				}
			}
		}

		{
			s32 x = 0;
			s32 y = 0;
			while( 1 )
			{

				u32 color; n_bmp_ptr_get_fast( &b, x, y, &color );
				if ( ( color == n_bmp_black )||( color == n_bmp_black_invisible ) )
				{
					n_bmp_ptr_set_fast( &b, x, y, n_win_icon_init_link_color_bg );
				}

				x++;
				if ( x >= N_BMP_SX( &b ) )
				{
					x = 0;

					y++;
					if ( y >= N_BMP_SY( &b ) ) { break; }
				}
			}
		}

		n_bmp_flush_blendcopy( &b_arrow, &b, 0.125 );

		s32 x = 0;
		s32 y = 0;
		while( 1 )
		{

			u32 color; n_bmp_ptr_get_fast( &m_arrow, x, y, &color );
			if ( color == n_bmp_black )
			{
				n_bmp_ptr_set_fast( &m, x, y, color );
			}

			x++;
			if ( x >= N_BMP_SX( &m_arrow ) )
			{
				x = 0;

				y++;
				if ( y >= N_BMP_SY( &m_arrow ) ) { break; }
			}
		}
//n_bmp_save_literal( &b_arrow, "./b_arrow.bmp" );
//n_bmp_save_literal( &m_arrow, "./m_arrow.bmp" );

		n_bmp_free_fast( &b_arrow );
		n_bmp_free_fast( &m_arrow );

//n_bmp_save_literal( &b, "./b.bmp" );
//n_bmp_save_literal( &m, "./m.bmp" );
	}


//n_bmp_save_literal( &b, "./b.bmp" );
//n_bmp_save_literal( &m, "./m.bmp" );

//n_bmp_flush( &b, 0xffffffff );
//n_bmp_flush( &m, 0xffffffff );

// 16x16 : 4byte == 16 pixel : bottom half will be applied
//n_bmp_box( &m, 0,0, 2,1, 0 );

//if ( n_win_icon_init_resource_size != -1 )
//{
//n_bmp_save_literal( &b, "./b.bmp" );
//n_bmp_save_literal( &m, "./m.bmp" );
//}
	n_win_icon_exit( hicon );

	if ( bmp != NULL )
	{

		hicon = NULL;

		n_bmp_free_fast( bmp );
		n_bmp_free_fast( msk );

		n_bmp_alias( &b, bmp );
		n_bmp_alias( &m, msk );

	} else {

		hicon = n_win_icon_bmp2hicon( &b, &m );

		n_bmp_free_fast( &b );
		n_bmp_free_fast( &m );

	}


	return hicon;
}


//#pragma GCC pop_options




HICON
n_win_icon_get( HWND hgui )
{

	// [!] : GDI handle leak : don't use a returned icon as the last icon to destroy

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		return (HICON) n_win_message_send( hgui, STM_GETIMAGE, IMAGE_ICON, 0 );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		return (HICON) n_win_message_send( hgui, BM_GETIMAGE,  IMAGE_ICON, 0 );
	}


	return NULL;
}

#define n_win_icon_del( h ) n_win_icon_set( h, NULL )

#define n_win_icon_add(         h, s, i ) n_win_icon_set( h, n_win_icon_init(         s, i, true ) )
#define n_win_icon_add_literal( h, s, i ) n_win_icon_set( h, n_win_icon_init_literal( s, i, true ) )

void
n_win_icon_set( HWND hgui, HICON hicon )
{
//n_win_icon_exit( hicon ); return;

	if ( n_win_class_is_same_literal( hgui, "Static" ) )
	{
		n_win_icon_exit( (HICON) n_win_message_send( hgui, STM_SETIMAGE, IMAGE_ICON, hicon ) );
	} else
	if ( n_win_class_is_same_literal( hgui, "Button" ) )
	{
		n_win_icon_exit( (HICON) n_win_message_send( hgui, BM_SETIMAGE,  IMAGE_ICON, hicon ) );
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_ICON

