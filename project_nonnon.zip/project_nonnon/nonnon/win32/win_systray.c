// nmixer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html



// [!] : <shellapi.h>


// [!] : Size : classic scheme
//
//	tray icon == title bar font == clock font
//
//	+ icon will be ugly when size has changed
//	+ you need to do n_win_systray_icon_change() to fix




#ifndef _H_NONNON_WIN32_WIN_SYSTRAY
#define _H_NONNON_WIN32_WIN_SYSTRAY




#include "../neutral/posix.c"


#include "./win/icon.c"




// [!] : don't use WM_USER

#define N_WIN_SYSTRAY_MESSAGE WM_APP




#define n_win_systray_init_literal( a,b,c,d,e,f ) n_win_systray_init( a, b, c, n_posix_literal( d ), n_posix_literal( e ), f )

void
n_win_systray_init
(
	      NOTIFYICONDATA *nid,
	                HWND  hwnd,
	                UINT  id,
	        n_posix_char *icon,
	const   n_posix_char *tip,
	                bool  draw
)
{

	if ( nid == NULL ) { return; }


	// [Mechanism]
	//
	//	icon : icon resource name


	HINSTANCE hinst = GetModuleHandle( NULL );


	nid->cbSize           = sizeof( NOTIFYICONDATA );
	nid->hWnd             = hwnd;
	nid->uID              = id;
	nid->uFlags           = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	nid->uCallbackMessage = N_WIN_SYSTRAY_MESSAGE;
	nid->hIcon            = LoadImage( hinst, icon, IMAGE_ICON, 0,0, LR_DEFAULTCOLOR );


	// [!] : WinXP : notify area manager uses this data

	if ( 64 > n_posix_strlen( tip ) )
	{
		n_posix_sprintf_literal( nid->szTip, "%s", tip );
	}


	if ( draw )
	{
		Shell_NotifyIcon( NIM_ADD, nid );
	}


	return;
}

void
n_win_systray_exit( NOTIFYICONDATA *nid )
{

	if ( nid == NULL ) { return; }


	Shell_NotifyIcon( NIM_DELETE, nid );


	// [Needed] : prevent handle leak

	n_win_icon_exit( nid->hIcon );


	ZeroMemory( nid, sizeof( NOTIFYICONDATA ) );


	return;
}

#define n_win_systray_icon_change_literal( a, b ) n_win_systray_icon_change( a, n_posix_literal( b ) )

// internal
void
n_win_systray_icon_change( NOTIFYICONDATA *nid, n_posix_char *name, int index )
{

	if ( nid == NULL ) { return; }


	n_win_icon_exit( nid->hIcon );

	int p_stop = n_win_icon_init_stop; n_win_icon_init_stop = 8;
	nid->hIcon = n_win_icon_init_small( name, index, N_WIN_ICON_INIT_OPTION_RESOURCE );
	n_win_icon_init_stop = p_stop;

	Shell_NotifyIcon( NIM_MODIFY, nid );


	return;
}


#endif // _H_NONNON_WIN32_WIN_SYSTRAY

