// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




bool
n_win_txtbox_is_highlighted_main( n_win_txtbox *p, s32 x, s32 y )
{

	if ( p == NULL ) { return false; }


	s32 sx = p->select_cch_sx;
	s32 sy = p->select_cch_sy;

	if ( sx == 0 ) { return false; }
	if ( sy == 0 ) { return false; }

	if ( sx == N_WIN_TXTBOX_ALL ) { sx = x + 1; }
	if ( sy == N_WIN_TXTBOX_ALL ) { sy = y + 1; }


	s32 fx = p->select_cch_x;
	s32 fy = p->select_cch_y;
	s32 tx = p->select_cch_x + sx - 1;
	s32 ty = p->select_cch_y + sy - 1;

	if (
		( ( fx <= x )&&( x <= tx ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		return true;
	}

	if (
		( ( y != fy )&&( y != ty ) )
		&&
		( ( fy <= y )&&( y <= ty ) )
	)
	{
		if (
			( p->line_min_onoff )
			||
			( p->line_max_onoff )
		)
		{
			return true;
		}
	}


	return false;
}

bool
n_win_txtbox_is_highlighted( n_win_txtbox *p, s32 x, s32 y )
{

	if ( p == NULL ) { return false; }


	if ( y == p->select_cch_y )
	{
//n_win_txtbox_hwndprintf_literal( p, " Min " );

		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{

			if ( p->line_min_cch_x <= x )
			{
				return true;
			}

		} else {

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else
	if ( y == ( p->select_cch_y + p->select_cch_sy - 1 ) )
	{
//n_win_txtbox_hwndprintf_literal( p, " Max " );

		if ( ( p->line_min_onoff )||( p->line_max_onoff ) )
		{

			if ( p->line_max_cch_x > x )
			{
				return true;
			}

		} else {

			return n_win_txtbox_is_highlighted_main( p, x,y );

		}

	} else {
//n_win_txtbox_hwndprintf_literal( p, " N/A " );

		return n_win_txtbox_is_highlighted_main( p, x,y );

	}


	return false;
}


