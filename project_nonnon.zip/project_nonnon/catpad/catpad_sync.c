// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifdef UNICODE

#define n_catpad_sync_name          n_posix_literal( "Nonnon.CatPad.Sync.W" )
#define n_catpad_sync_name_is_exist n_posix_literal( "Nonnon.CatPad.Sync.IsExist.W" )

#else  // #ifdef UNICODE

#define n_catpad_sync_name          n_posix_literal( "Nonnon.CatPad.Sync.A" )
#define n_catpad_sync_name_is_exist n_posix_literal( "Nonnon.CatPad.Sync.IsExist.A" )

#endif // #ifdef UNICODE




static UINT         n_catpad_sync_msg;
static UINT         n_catpad_sync_msg_is_exist;
static n_posix_char n_catpad_sync_str[ N_CATPAD_SYNC_CCH ];
static bool         n_catpad_sync_is_first = true;




#define n_catpad_sync_get() n_catpad_sync_getset(  true )
#define n_catpad_sync_set() n_catpad_sync_getset( false )

HANDLE
n_catpad_sync_getset( bool is_get )
{

	HANDLE        hmap;
	n_posix_char *s;
	DWORD         byte = N_CATPAD_SYNC_CCH * sizeof( n_posix_char );


	hmap = CreateFileMapping( INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0,byte, n_catpad_sync_name );
	s    = MapViewOfFile( hmap, FILE_MAP_ALL_ACCESS, 0,0, 0 );

	if ( s != NULL )
	{

		if ( is_get )
		{
//n_posix_debug_literal( "Get : %s\n%s", s, n_catpad_sync_str );
			n_string_copy( s, n_catpad_sync_str );
		} else {
//n_posix_debug_literal( "Set : %s\n%s", n_catpad_sync_str, s );
			n_string_copy( n_catpad_sync_str, s );
		}

	}


	UnmapViewOfFile( s );


	return hmap;
}

void
n_catpad_sync_init( void )
{

	n_catpad_sync_msg          = RegisterWindowMessage( n_catpad_sync_name          );
	n_catpad_sync_msg_is_exist = RegisterWindowMessage( n_catpad_sync_name_is_exist );

	n_string_zero( n_catpad_sync_str, N_CATPAD_SYNC_CCH );


	// [!] : try to load from another CatPad

	n_catpad_sync_get();


	return;
}

void
n_catpad_sync_exit( void )
{

	// [!] : simply fail when other processes exist

	CloseHandle( n_catpad_sync_set() );


	return;
}

// internal
BOOL CALLBACK
n_catpad_sync_EnumWindows( HWND hwnd, LPARAM lparam )
{

	HWND hwnd_self = (HWND) lparam;

	if ( hwnd != hwnd_self )
	{

		bool is_exist = n_win_message_send( hwnd, n_catpad_sync_msg_is_exist, 0,0 );

		n_catpad_sync_is_first = ( is_exist == false );

		if ( n_catpad_sync_is_first == false )
		{
//n_posix_debug_literal( " ! " );
			return false;
		}

	}


	return true;
}

bool
n_catpad_sync_is_first_check( HWND hwnd )
{

	n_catpad_sync_is_first = true;

	EnumWindows( n_catpad_sync_EnumWindows, (LPARAM) hwnd );


	return n_catpad_sync_is_first;
}

void
n_catpad_sync_send( HWND hwnd, const n_posix_char *str )
{

	// [Needed] : prevent memory-leak

	n_string_copy( str, n_catpad_sync_str );

	CloseHandle( n_catpad_sync_set() );


	// [!] : don't use SendMessage() : hangup in some cases

	SendNotifyMessage( HWND_BROADCAST, n_catpad_sync_msg, 0, (LPARAM) hwnd );


	return;
}

void
n_catpad_sync_recv( HWND hwnd, n_posix_char *str )
{

	//if ( n_string_is_empty( n_catpad_sync_str ) ) { return; }

	n_string_copy( n_catpad_sync_str, str );


	return;
}

bool
n_catpad_sync_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	if ( msg != n_catpad_sync_msg ) { return false; }


#ifdef UNICODE

	if ( false == IsWindowUnicode( (HWND) lparam ) ) { return false; }

#else // #ifdef UNICODE

	if ( IsWindowUnicode( (HWND) lparam ) ) { return false; }

#endif // #ifdef UNICODE


	// [Needed] : anti-memory-leak

	CloseHandle( n_catpad_sync_get() );


	return true;
}

