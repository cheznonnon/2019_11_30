

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include <windows.h>
#include <commdlg.h>




int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	CHOOSECOLOR cc;
	COLORREF    colors[ 16 ];


	int i = 0;
	while( 1 )
	{

		colors[ i ] = RGB( 255,255,255 );

		i++;
		if ( i >= 16 ) { break; }
	}


	ZeroMemory( &cc, sizeof(CHOOSECOLOR) );

	cc.lStructSize  = sizeof(CHOOSECOLOR);
	cc.rgbResult    = RGB( 255,255,255 );
	cc.lpCustColors = colors;
	cc.Flags        = CC_RGBINIT | CC_FULLOPEN;


	if ( ChooseColor( &cc ) )
	{

		char str[ PATH_MAX ];


		sprintf( str, "%lx", cc.rgbResult );

		MessageBoxA( NULL, str, "DEBUG", 0 );

	}


	return 0;
}

