



#include "../../nonnon/win32/win.c"
#include "../../nonnon/win32/win_separator.c"

#include "../../nonnon/project/macro.c"




void
n_static_gui( HWND hwnd_parent, DWORD exstyle, DWORD style, void *data, HWND *hgui )
{

	*hgui = CreateWindowEx
	(
		exstyle,
		TEXT( "STATIC" ),
		data,
		style | WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
		0,0, 0,0,
		hwnd_parent,
		(HMENU) NULL,
		GetModuleHandle( NULL ),
		NULL
	);

	n_win_font_default( *hgui, false );


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	const char *name_ico = "../../nonnon/project/neko.multi.ico";
	const char *name_bmp = "./neko.bmp";


	const char *imagestr = {

		"[0] : SS_ICON"
		"\n"
		"[1] : SS_ICON | SS_REALSIZEIMAGE"
		"\n"
		"[2] : SS_ICON | SS_CENTERIMAGE"
		"\n"
		"[3] : SS_ICON | SS_RIGHTJUST"
		"\n"
		"[4] : SS_BITMAP"
		"\n"
		"[5] : SS_BITMAP | SS_REALSIZEIMAGE"
		"\n"
		"[6] : SS_BITMAP | SS_CENTERIMAGE"
		"\n"
		"[7] : SS_BITMAP | SS_RIGHTJUST"

	};

	const char *ss_endellipsis = {

		"SS_ENDELLIPSIS ss_endellipsis"
		" "
		"SS_ENDELLIPSIS ss_endellipsis"

	};

	const char *ss_pathellipsis = {

		"C:"
		"\\"
		"SS_PATHELLIPSIS"
		"\\"
		"ss_pathellipsis"
		"\\"
		"SS_PATHELLIPSIS"
		"\\"
		"ss_pathellipsis"

	};

	const char *ss_wordellipsis = {

		"SS_WORDELLIPSIS ss_wordellipsis"
		" "
		"SS_WORDELLIPSIS ss_wordellipsis"

	};


	static HWND    hgui[ 50 ];
	static HICON   ico;
	static HBITMAP bmp;


	switch( msg ) {


	case WM_CREATE :


		// Window

		n_win_init_literal( hwnd, "Nonnon Static Catalog", "", "" );


		n_win_gui( hwnd, STATIC, "SS_LEFT",   &hgui[0] );
		n_win_gui( hwnd, STATIC, "SS_CENTER", &hgui[1] );
		n_win_gui( hwnd, STATIC, "SS_RIGHT",  &hgui[2] );

		n_win_gui( hwnd, STATIC, "SS_CENTER | SS_CENTERIMAGE", &hgui[38] );

		n_win_gui( hwnd, STATIC, "", &hgui[ 3] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 4] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 5] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 6] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 7] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 8] );
		n_win_gui( hwnd, STATIC, "", &hgui[ 9] );
		n_win_gui( hwnd, STATIC, "", &hgui[10] );

		n_win_gui( hwnd, STATIC, "[0]", &hgui[11] );
		n_win_gui( hwnd, STATIC, "[1]", &hgui[12] );
		n_win_gui( hwnd, STATIC, "[2]", &hgui[13] );
		n_win_gui( hwnd, STATIC, "[3]", &hgui[14] );
		n_win_gui( hwnd, STATIC, "[4]", &hgui[15] );
		n_win_gui( hwnd, STATIC, "[5]", &hgui[16] );
		n_win_gui( hwnd, STATIC, "[6]", &hgui[17] );
		n_win_gui( hwnd, STATIC, "[7]", &hgui[18] );

		n_win_gui( hwnd, STATIC, imagestr, &hgui[19] );


		n_win_gui( hwnd, STATIC, "SS_BLACKRECT",   &hgui[20] );
		n_win_gui( hwnd, STATIC, "SS_GRAYRECT",    &hgui[21] );
		n_win_gui( hwnd, STATIC, "SS_WHITERECT",   &hgui[22] );
		n_win_gui( hwnd, STATIC, "BLACK_BRUSH",    &hgui[23] );


		n_win_gui( hwnd, STATIC, "SS_BLACKFRAME",  &hgui[24] );
		n_win_gui( hwnd, STATIC, "SS_GRAYFRAME",   &hgui[25] );
		n_win_gui( hwnd, STATIC, "SS_WHITEFRAME",  &hgui[26] );
		n_win_gui( hwnd, STATIC, "SS_ETCHEDFRAME", &hgui[27] );


		n_static_gui( hwnd, 0, SS_SUNKEN, "SS_SUNKEN",  &hgui[28] );
		n_win_gui( hwnd, STATIC, "WS_BORDER",           &hgui[29] );
		n_win_gui( hwnd, STATIC, "WS_THICKFRAME",       &hgui[30] );
		n_win_gui( hwnd, STATIC, "WS_EX_CLIENTEDGE",    &hgui[31] );
		n_win_gui( hwnd, STATIC, "WS_EX_DLGMODALFRAME", &hgui[32] );
		n_win_gui( hwnd, STATIC, "WS_EX_STATICEDGE",    &hgui[33] );


		n_win_gui( hwnd, STATIC, "SS_OWNERDRAW", &hgui[34] );


		n_win_gui( hwnd, STATIC, ss_endellipsis,  &hgui[35] );
		n_win_gui( hwnd, STATIC, ss_pathellipsis, &hgui[36] );
		n_win_gui( hwnd, STATIC, ss_wordellipsis, &hgui[37] );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_style_add( hgui[ 0], WS_BORDER | SS_LEFT );
		n_win_style_add( hgui[ 1], WS_BORDER | SS_CENTER );
		n_win_style_add( hgui[ 2], WS_BORDER | SS_RIGHT );
		n_win_style_add( hgui[38], WS_BORDER | SS_CENTER | SS_CENTERIMAGE );

		n_win_style_add( hgui[39], WS_EX_STATICEDGE );
		n_win_style_add( hgui[40], WS_EX_STATICEDGE );

		n_win_style_add( hgui[ 3], SS_ICON );
		n_win_style_add( hgui[ 4], SS_ICON   | SS_REALSIZEIMAGE );
		n_win_style_add( hgui[ 5], SS_ICON   | SS_CENTERIMAGE );
		n_win_style_add( hgui[ 6], SS_ICON   | SS_RIGHTJUST );
		n_win_style_add( hgui[ 7], SS_BITMAP );
		n_win_style_add( hgui[ 8], SS_BITMAP | SS_REALSIZEIMAGE );
		n_win_style_add( hgui[ 9], SS_BITMAP | SS_CENTERIMAGE );
		n_win_style_add( hgui[10], SS_BITMAP | SS_RIGHTJUST );

		ico = n_win_icon_init( name_ico, N_WIN_ICON_INIT_OPTION_DEFAULT );
		bmp = n_win_bitmap_init( name_bmp );

		n_win_icon_set  ( hgui[ 3], ico );
		n_win_icon_set  ( hgui[ 4], ico );
		n_win_icon_set  ( hgui[ 5], ico );
		n_win_icon_set  ( hgui[ 6], ico );
		n_win_bitmap_set( hgui[ 7], bmp );
		n_win_bitmap_set( hgui[ 8], bmp );
		n_win_bitmap_set( hgui[ 9], bmp );
		n_win_bitmap_set( hgui[10], bmp );

//n_win_style_add( hgui[19], SS_LEFTNOWORDWRAP );


		n_win_style_add( hgui[11], SS_CENTER );
		n_win_style_add( hgui[12], SS_CENTER );
		n_win_style_add( hgui[13], SS_CENTER );
		n_win_style_add( hgui[14], SS_CENTER );
		n_win_style_add( hgui[15], SS_CENTER );
		n_win_style_add( hgui[16], SS_CENTER );
		n_win_style_add( hgui[17], SS_CENTER );
		n_win_style_add( hgui[18], SS_CENTER );

		//[19]


		n_win_style_add( hgui[20], SS_BLACKRECT );
		n_win_style_add( hgui[21], SS_GRAYRECT  );
		n_win_style_add( hgui[22], SS_WHITERECT );
		//[23]

		n_win_style_add( hgui[24], SS_BLACKFRAME  );
		n_win_style_add( hgui[25], SS_GRAYFRAME   );
		n_win_style_add( hgui[26], SS_WHITEFRAME  );
		n_win_style_add( hgui[27], SS_ETCHEDFRAME );


		//[28]
		n_win_style_add  ( hgui[29], WS_BORDER );
		n_win_style_add  ( hgui[30], WS_THICKFRAME );
		n_win_exstyle_add( hgui[31], WS_EX_CLIENTEDGE );
		n_win_exstyle_add( hgui[32], WS_EX_DLGMODALFRAME );
		n_win_exstyle_add( hgui[33], WS_EX_STATICEDGE );


		n_win_style_add( hgui[34], SS_OWNERDRAW );


		n_win_style_add( hgui[35], SS_ENDELLIPSIS  );
		n_win_style_add( hgui[36], SS_PATHELLIPSIS );
		n_win_style_add( hgui[37], SS_WORDELLIPSIS );


		// Size

		{

		const bool redraw = true;


		s32 ctl,ico,m;
		n_win_stdsize( hwnd, &ctl, &ico, &m );


		// [!] : difference between styles

		ico += m;


		s32 csy = ( ico * 2 ) + ( ico + ctl ) + ( ctl * 6 ) + ( ctl * 11 );
		s32 csx = ( ico * 8 );

		n_win_set( hwnd, NULL, csx + m, csy + m, N_WIN_SET_CENTERING );


		s32 half  = ( csx - m ) / 2;
		s32 third = ( csx - m ) / 3;
		s32 ln8   = ( ctl * 6 );

		s32 x = 0;
		s32 y = 0;

		n_win_move( hgui[ 0], x, y, third, ico, redraw ); x += third;
		n_win_move( hgui[ 1], x, y, third, ico, redraw ); x += third;
		n_win_move( hgui[ 2], x, y, third, ico, redraw ); x += third; y += ico; x = 0;
		n_win_move( hgui[38], x, y,   csx, ico, redraw ); x += csx;   y += ico; x = 0;

		n_win_move( hgui[ 3], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 4], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 5], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 6], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 7], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 8], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[ 9], x, y,   ico, ico, redraw ); x += ico;
		n_win_move( hgui[10], x, y,   ico, ico, redraw ); x += ico;  y += ico; x = 0;

		n_win_move( hgui[11], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[12], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[13], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[14], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[15], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[16], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[17], x, y,   ico, ctl, redraw ); x += ico;
		n_win_move( hgui[18], x, y,   ico, ctl, redraw ); x += ico;  y += ctl; x = 0;

		n_win_move( hgui[19], x, y,   csx, ln8, redraw ); x += csx;  y += ln8; x = 0;

		n_win_move( hgui[20], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[24], x, y,  half, ctl, redraw ); y += ctl;  x = 0;
		n_win_move( hgui[21], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[25], x, y,  half, ctl, redraw ); y += ctl;  x = 0;
		n_win_move( hgui[22], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[26], x, y,  half, ctl, redraw ); y += ctl;  x = 0;
		n_win_move( hgui[23], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[27], x, y,  half, ctl, redraw ); y += ctl;  x = 0;


		n_win_move( hgui[28], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[31], x, y,  half, ctl, redraw ); y += ctl;  x = 0;
		n_win_move( hgui[29], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[32], x, y,  half, ctl, redraw ); y += ctl;  x = 0;
		n_win_move( hgui[30], x, y,  half, ctl, redraw ); x += half;
		n_win_move( hgui[33], x, y,  half, ctl, redraw ); y += ctl;  x = 0;

		n_win_move( hgui[34], x, y,   csx, ctl, redraw ); y += ctl;

		n_win_move( hgui[35], x, y,   csx, ctl, redraw ); y += ctl;
		n_win_move( hgui[36], x, y,   csx, ctl, redraw ); y += ctl;
		n_win_move( hgui[37], x, y,   csx, ctl, redraw ); y += ctl;

		}


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CTLCOLORSTATIC :

		if ( (HWND) lparam == hgui[ 23 ] )
		{
			SetBkMode( (HDC) wparam, TRANSPARENT );
			SetTextColor( (HDC) wparam, RGB( 255,255,255 ) );

			return (LRESULT) GetStockObject( BLACK_BRUSH );
		}

	break;


	case WM_CLOSE :

		n_win_icon_exit  ( ico );
		n_win_bitmap_exit( bmp );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_separator_proc( hwnd, msg, wparam, lparam, hgui[ 34 ], PS_DOT );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{

	// for loading icon

	n_win_exedir2curdir();


	return n_win_main( NULL, WndProc );
}

