// Nonnon DirectX
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#define UNICODE


#include "../../../nonnon/win32/win.c"

#include "../../../nonnon/project/macro.c"




#include "./direct3d9.c"




void
n_dxtest_load( HWND hwnd, HWND hgui, n_bmp *bmp, const n_posix_char *name )
{

	n_win_text_set_literal( hwnd, "Nonnon D3D9 Test" );


	if ( n_bmp_load( bmp, name ) ) { n_bmp_new( bmp, 256,256 ); }


	n_win_set( hwnd, NULL, N_BMP_SX( bmp ), N_BMP_SY( bmp ), N_WIN_SET_CENTERING | N_WIN_SET_CLIPPING );

	if ( hgui != NULL )
	{
		n_win_move_simple( hgui, 0, 0, N_BMP_SX( bmp ), N_BMP_SY( bmp ), false );
	}


	n_d3d9_bitmap_init( N_BMP_SX( bmp ), N_BMP_SY( bmp ) );
	n_d3d9_bitmap_sync_all( bmp );


	if ( hgui != NULL )
	{
		n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow = hgui;
	} else {
		n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow = hwnd;
	}

	n_win_refresh( n_d3d9_D3DPRESENT_PARAMETERS.hDeviceWindow, true );


	return;
}

void
n_dxtest_draw( n_bmp *bmp )
{

	n_d3d9_bitmap_draw_all( bmp );
	//n_d3d9_bitmap_draw( bmp, 20,20,50,50 );


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND         hcanvas = NULL;
	static n_posix_char cmdline[ N_PATH_MAX ];
	static n_bmp        bmp;


	switch( msg ) {


	case WM_CREATE :

		n_d3d9_init( hwnd );


		n_win_init_literal( hwnd, "Nonnon D3D9 Test", "", "" );
		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		//n_win_gui_literal( hwnd, STATIC, "", &hcanvas );
		//n_win_style_add( hcanvas, SS_OWNERDRAW );


		n_win_commandline( cmdline );

		n_bmp_zero( &bmp );
		n_dxtest_load( hwnd, hcanvas, &bmp, cmdline );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_DROPFILES :

		n_win_dropfiles( hwnd, wparam, cmdline );

		n_dxtest_load( hwnd, hcanvas, &bmp, cmdline );

	break;


	case WM_ERASEBKGND :

		return TRUE;

	break;

	case WM_PAINT :
	case WM_DRAWITEM :

		n_dxtest_draw( &bmp );

	break;


	case WM_MOUSEMOVE :
	{

		// Paint Test

		if ( false == n_win_is_input( VK_LBUTTON ) ) { break; }

		n_bmp b;
		n_bmp_zero( &b );
		n_bmp_new( &b, 20,20 );
		n_bmp_flush( &b, n_bmp_rgb( 0,200,255 ) );

		s32 x,y;
		n_win_cursor_position_relative( hwnd, &x, &y );
		n_d3d9_bitmap_copy( &b, &bmp, 0,0,20,20, x-10,y-10 );
		n_d3d9_bitmap_draw( &bmp, x-10,y-10,20,20 );

		n_bmp_free( &b );

	}
	break;


	case WM_CLOSE :

		n_bmp_free( &bmp );

		n_d3d9_exit();

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{ // grabNdrag

	static bool onoff = false;
	static POINT        prv, cur;


	switch( msg ) {


	case WM_MBUTTONDOWN :

		n_win_cursor_add( NULL, IDC_SIZEALL );
		SetCapture( hwnd );

		GetCursorPos( &prv );

		onoff = true;

	break;

	case WM_MOUSEMOVE :
	{

		if ( onoff == false ) { break; }


		GetCursorPos( &cur );

		prv.x -= cur.x;
		prv.y -= cur.y;


		if ( hcanvas == NULL )
		{

			n_d3d9_bitmap_scroll( &bmp, -prv.x, -prv.y );
			n_d3d9_clear( RGB( 128,128,128 ) );

			n_d3d9_bitmap_draw_all( &bmp );

/*
			s32 sx,sy;
			n_win_size_client( hwnd, &sx, &sy );

			sx += abs( prv.x * 2 );
			sy += abs( prv.y * 2 );

			n_d3d9_bitmap_draw( &bmp, 0,0,sx,sy );
*/
		} else {

			// [x] : IDirect3DDevice9_Present() moves a child control to inner area

			s32 x,y,sx,sy;

			x = prv.x;
			y = prv.y;

			n_win_size_client( hcanvas, &sx, &sy );


			n_win_move_simple( hcanvas, x,y,sx,sy, false );

			n_win_refresh( hcanvas, true );

			//n_d3d9_bitmap_draw_all( &bmp );

		}


		prv = cur;

	}
	break;


	case WM_MBUTTONUP :

		onoff = false;

		ReleaseCapture();

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	} // switch

	} // grabNdrag


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

