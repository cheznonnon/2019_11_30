// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/neutral/filer.c"
#include "../nonnon/neutral/path.c"

#include "../nonnon/win32/win.c"
#include "../nonnon/win32/win_progressbar.c"




#define N_X64_SYNC_TIMER_ID   (   1 )
#define N_X64_SYNC_TIMER_MSEC ( 500 )




const bool  debug_onoff = false;//true;
const u32   debug_msec  = 200;


static int  n_x64_sync_count = 0;
static int  n_x64_sync_index = 0;

static bool n_x64_sync_timer_onoff = false;




void
n_x64_sync_apps( HWND hwnd, bool count_only )
{


	n_posix_char *f[] = {
		"Z:\\c\\arcdrop",
		"Z:\\c\\gameconsole",
		"Z:\\c\\nonnonapps",

		"Z:\\c\\cr2",
		"Z:\\c\\hunyapiyo2",
		"Z:\\c\\hunyapiyo3",
		"Z:\\c\\lm2",
		"Z:\\c\\nfreecell",
		"Z:\\c\\ngame",
		"Z:\\c\\nn",
		"Z:\\c\\nspider",

		"Z:\\c\\catpad",
		"Z:\\c\\charactermap",
		"Z:\\c\\felis",
		"Z:\\c\\marie",
		"Z:\\c\\n_attrib",
		"Z:\\c\\neko_no_te",
		"Z:\\c\\nmidi",
		"Z:\\c\\nmixer",
		"Z:\\c\\nonnon paint",
		"Z:\\c\\nyaurism",
		"Z:\\c\\orangecat",
		"Z:\\c\\pentrainer",
		"Z:\\c\\projectchecker",
		"Z:\\c\\watchcat",
		NULL
	};

	n_posix_char *t[] = {
		"Z:\\VC++\\ArcDrop\\ArcDrop",
		"Z:\\VC++\\GameConsole\\GameConsole",
		"Z:\\VC++\\NonnonApps\\NonnonApps",

		"Z:\\VC++\\GameConsole\\cr2",
		"Z:\\VC++\\GameConsole\\hunyapiyo2",
		"Z:\\VC++\\GameConsole\\hunyapiyo3",
		"Z:\\VC++\\GameConsole\\lm2",
		"Z:\\VC++\\GameConsole\\nfreecell",
		"Z:\\VC++\\GameConsole\\ngame",
		"Z:\\VC++\\GameConsole\\nn",
		"Z:\\VC++\\GameConsole\\nspider",

		"Z:\\VC++\\NonnonApps\\catpad",
		"Z:\\VC++\\NonnonApps\\charactermap",
		"Z:\\VC++\\NonnonApps\\felis",
		"Z:\\VC++\\NonnonApps\\marie",
		"Z:\\VC++\\NonnonApps\\n_attrib",
		"Z:\\VC++\\NonnonApps\\neko_no_te",
		"Z:\\VC++\\NonnonApps\\nmidi",
		"Z:\\VC++\\NonnonApps\\nmixer",
		"Z:\\VC++\\NonnonApps\\nonnon paint",
		"Z:\\VC++\\NonnonApps\\nyaurism",
		"Z:\\VC++\\NonnonApps\\orangecat",
		"Z:\\VC++\\NonnonApps\\pentrainer",
		"Z:\\VC++\\NonnonApps\\projectchecker",
		"Z:\\VC++\\NonnonApps\\watchcat",
		NULL
	};


	int i = 0;
	while( 1 )
	{

		if ( count_only )
		{

			n_x64_sync_count++;

		} else {

			if ( debug_onoff )
			{
				n_posix_sleep( debug_msec );
			} else {
				n_filer_merge( f[ i ], t[ i ] );
			}

			n_posix_char name[ 1024 ]; n_path_name( t[ i ], name );

			n_x64_sync_index++;
			n_win_hwndprintf_literal( hwnd, "%d/%d : Apps : %s", n_x64_sync_index, n_x64_sync_count, name );
			n_win_message_send( hwnd, WM_PAINT, 0, 0 );

		}


		i++;
		if ( t[ i ] == NULL ) { break; }
	}

}

void
n_x64_sync_base( HWND hwnd, bool count_only )
{

	n_posix_char *f = "Z:\\c\\nonnon";

	n_posix_char *t[] = {
		"Z:\\VC++\\ArcDrop",
		"Z:\\VC++\\GameConsole",
		"Z:\\VC++\\NonnonApps",
		NULL
	};


	int i = 0;
	while( 1 )
	{

		n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "%s\\nonnon", t[ i ] );

		if ( count_only )
		{

			n_x64_sync_count++;

		} else {

			if ( debug_onoff )
			{
				n_posix_sleep( debug_msec );
			} else {
				n_filer_merge( f, str );
//n_posix_debug_literal( "%s", str );
			}

			n_posix_char name[ 1024 ]; n_path_name( t[ i ], name );

			n_x64_sync_index++;
			n_win_hwndprintf_literal( hwnd, "%d/%d : Base : %s", n_x64_sync_index, n_x64_sync_count, name );
			n_win_message_send( hwnd, WM_PAINT, 0, 0 );

		}


		i++;
		if ( t[ i ] == NULL ) { break; }
	}


	return;
}

LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui = NULL;


	switch( msg ) {


	case WM_CREATE :

		n_win_init_literal( hwnd, "x64 Sync", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "Click Here", &hgui );
		n_win_stdfont_init( &hgui, 1 );


		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		{
			s32 ctl; n_win_stdsize( hwnd, &ctl, NULL, NULL );

			n_win_set( hwnd, NULL, 256,ctl*2, N_WIN_SET_CENTERING );
			MoveWindow( hgui, ctl/2,ctl/2,256-ctl,ctl, true );
		}


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_LBUTTONDOWN :

		n_win_cursor_add( NULL, IDC_WAIT );

		n_x64_sync_count = 0;
		n_x64_sync_index = 0;

		n_x64_sync_base( hgui, true );
		n_x64_sync_apps( hgui, true );

		n_x64_sync_base( hgui, false );
		n_x64_sync_apps( hgui, false );

		n_win_cursor_add( NULL, IDC_ARROW );

	break;


	case WM_TIMER :

		// [!] : Win95 needs to check WPARAM is ID or not

		if ( wparam == N_X64_SYNC_TIMER_ID )
		{

			static int phase = 0;

			if ( phase == 0 )
			{
				phase = 1;
				n_win_hwndprintf_literal( hgui, "Done!" );
			} else
			if ( phase == 1 )
			{
				n_win_message_send( hwnd, WM_CLOSE, 0,0 );
			}

		}

	break;


	case WM_CLOSE :

		n_win_stdfont_exit( &hgui, 1 );

		n_win_timer_exit( hwnd, N_X64_SYNC_TIMER_ID );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	{
		u32 fg = GetSysColor( COLOR_HIGHLIGHT );
		u32 bg = GetSysColor( COLOR_BTNFACE   );

		int percent = 0;
		if ( n_x64_sync_count != 0 )
		{
			percent = (double) n_x64_sync_index / n_x64_sync_count * 100;
			if ( percent >= 100 )
			{
				if ( n_x64_sync_timer_onoff == false )
				{
					n_x64_sync_timer_onoff = true;
					SetTimer( hwnd, N_X64_SYNC_TIMER_ID, N_X64_SYNC_TIMER_MSEC, NULL );
				}
			}
		}

		n_win_progressbar_proc( hwnd,msg,wparam,lparam, hgui, EDGE_ETCHED, percent, fg,bg );
	}


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

