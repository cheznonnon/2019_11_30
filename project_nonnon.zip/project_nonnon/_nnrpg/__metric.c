// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




typedef struct {


	// Zoom

	s32 zoom;
	s32 csx, csy;


	// Unit

	s32 unit_bmp;
	s32 unit_pad;


	// Color

	u32 color_trans;

	u32 color_window_1;
	u32 color_window_2;

	u32 color_attack;
	u32 color_magic;
	u32 color_heal;


	// Position and Size

	s32 command_x, command_y, command_sx, command_sy;
	s32 mainwin_x, mainwin_y, mainwin_sx, mainwin_sy;
	s32 chara_0_x, chara_0_y;
	s32 chara_1_x, chara_1_y;
	s32 chara_2_x, chara_2_y;


	// Font

	n_posix_char *font;
	s32           textsize;


	// Target Canvas

	n_bmp *bg;
	n_bmp *canvas;


} n_metric;


static n_metric metric;




void
n_metric_make( void )
{

	// Zoom : 1 or 2 only supported

	s32 desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	metric.zoom = n_posix_minmax( 1, 2, desktop_sx / 640 );

	{

		// [!] : reverse

		n_posix_char *cmdline = n_win_commandline_new();

		if ( false == n_string_is_empty( cmdline ) )
		{
			if ( metric.zoom == 1 ) { metric.zoom = 2; } else { metric.zoom = 1; }
		}

		n_string_free( cmdline ); 

	}

	metric.csx = 320 * metric.zoom;
	metric.csy = 240 * metric.zoom;


	// Color

	metric.color_trans    = n_bmp_white_invisible;

	metric.color_window_1 = n_bmp_argb( 128,  0,100,150 );
	metric.color_window_2 = n_bmp_argb( 128,  0,  0, 50 );

	metric.color_attack   = n_bmp_rgb( 255,255,255 );
	metric.color_magic    = n_bmp_rgb( 255,255,  0 );
	metric.color_heal     = n_bmp_rgb(   0,200,255 );


	// Position and Size

	s32 unit_sx = ( metric.csx / 4 );
	s32 unit_sy = ( metric.csy / 3 );
	s32 main_sy = metric.csy - unit_sy;


	metric.font       = n_project_stdfont();//n_posix_literal( "Arial" );//
	metric.textsize   = 16 * metric.zoom;

	if ( n_string_is_same_literal( "Arial", metric.font ) )
	{
		metric.textsize = (double) metric.textsize * 0.66;
	}


	metric.command_x  = 0;
	metric.command_y  = unit_sy * 2;
	metric.command_sx = unit_sx * 1;
	metric.command_sy = unit_sy * 1;
	metric.mainwin_x  = metric.command_sx;
	metric.mainwin_y  = metric.command_y;
	metric.mainwin_sx = unit_sx * 3;
	metric.mainwin_sy = unit_sy * 1;


	metric.unit_bmp = 64 * metric.zoom;
	metric.unit_pad =  4 * metric.zoom;

	metric.chara_0_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, metric.unit_bmp / 2 );
	metric.chara_1_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, metric.unit_bmp / 2 );
	metric.chara_2_x  = ( unit_sx * 0 ) + n_game_centering( unit_sx * 3, metric.unit_bmp / 1 );

	metric.chara_0_y  = ( main_sy / 2 ) - metric.unit_bmp;
	metric.chara_1_y  = ( main_sy / 2 );
	metric.chara_2_y  = n_game_centering( main_sy / 1, metric.unit_bmp );


	// Target Canvas

	metric.bg     = &bmp_bg;
	metric.canvas = &game.bmp;


	return;
}

